import { cn } from "@/lib/utils";

type Props = {
  label?: string;
  className?: string;
  /** leaderboard = wide banner, rectangle = in-content, tower = sidebar */
  format?: "leaderboard" | "rectangle" | "tower";
};

const sizes = {
  leaderboard: "min-h-[90px] md:min-h-[110px]",
  rectangle: "min-h-[250px]",
  tower: "min-h-[600px]",
};

/**
 * Reserved, empty ad space styled as an elegant "featured" divider.
 * Drop an AdSense <ins> tag inside when ready — height is reserved to
 * avoid layout shift.
 */
export function AdSlot({ label = "Featured", className, format = "leaderboard" }: Props) {
  return (
    <div
      data-ad-slot={format}
      className={cn(
        "relative flex w-full items-center justify-center overflow-hidden rounded-2xl border border-border/70 bg-[linear-gradient(135deg,color-mix(in_oklab,var(--accent-vivid)_6%,transparent),transparent_55%)]",
        sizes[format],
        className,
      )}
    >
      <span
        aria-hidden
        className="absolute inset-x-6 top-1/2 h-px -translate-y-1/2 bg-[linear-gradient(90deg,transparent,var(--border),transparent)]"
      />
      <span className="relative rounded-full bg-background px-4 py-1.5 text-[11px] font-semibold uppercase tracking-[0.28em] text-muted-foreground/80">
        {label}
      </span>
    </div>
  );
}
