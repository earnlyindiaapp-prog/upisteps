import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    q: "What does UPISTEPS actually cover?",
    a: "Practical engineering coverage across artificial intelligence, web development, cloud infrastructure, security and hardware. Every piece is written by someone who has shipped the thing they are describing.",
  },
  {
    q: "How often do you publish?",
    a: "Three to five deeply edited articles a week, plus a short daily digest for subscribers. We would rather publish one useful piece than five reactive ones.",
  },
  {
    q: "Do you accept sponsored posts?",
    a: "Sponsorships are clearly labelled and never influence editorial coverage. Reviews and benchmarks are always independent, and we publish our methodology alongside results.",
  },
  {
    q: "Can I contribute an article?",
    a: "Yes. We look for first-hand accounts with numbers: migrations, incidents, cost reductions, benchmarks. Pitch a two-paragraph outline through the contact page.",
  },
  {
    q: "How do you keep articles fresh?",
    a: "Anything that ages quickly gets revisited on a schedule. Updated pieces show a Last Updated badge at the top so you always know how current the guidance is.",
  },
  {
    q: "Is there an RSS feed or newsletter?",
    a: "Both. The newsletter lands each morning, and the feed carries every article in full text with no tracking pixels.",
  },
];

export function FaqSection() {
  return (
    <div className="grid gap-10 lg:grid-cols-[0.8fr_1.2fr]">
      <div>
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent-vivid">
          Community
        </p>
        <h2 className="text-gradient mt-3 text-3xl md:text-4xl">Questions, answered</h2>
        <p className="mt-4 text-sm leading-relaxed text-muted-foreground md:text-base">
          Everything readers ask most about how this publication works, how we choose stories, and
          how you can take part.
        </p>
      </div>
      <Accordion type="single" collapsible className="w-full">
        {faqs.map((f) => (
          <AccordionItem
            key={f.q}
            value={f.q}
            className="rounded-xl border border-border/70 px-4 transition-colors duration-300 hover:border-[color-mix(in_oklab,var(--accent-vivid)_45%,transparent)] data-[state=open]:border-[color-mix(in_oklab,var(--accent-vivid)_45%,transparent)] mb-3"
          >
            <AccordionTrigger className="text-left text-base font-semibold hover:text-accent-vivid hover:no-underline">
              {f.q}
            </AccordionTrigger>
            <AccordionContent className="text-sm leading-relaxed text-muted-foreground">
              {f.a}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  );
}
