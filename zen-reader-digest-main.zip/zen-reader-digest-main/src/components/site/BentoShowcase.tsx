import { Link } from "@tanstack/react-router";
import { ArrowUpRight, Cpu, Gauge, Layers, ShieldCheck, Sparkles } from "lucide-react";

const specTag =
  "inline-flex items-center rounded-full border border-white/15 bg-white/5 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-white/70";

const cardBase =
  "group relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] p-5 backdrop-blur-xl transition-all duration-500 ease-out hover:border-white/25 hover:bg-white/[0.06] hover:shadow-[0_0_0_1px_rgba(255,255,255,0.08),0_30px_60px_-30px_color-mix(in_oklab,var(--accent-vivid)_75%,transparent)]";

export function BentoShowcase() {
  return (
    <section className="relative isolate overflow-hidden rounded-[28px] border border-white/10 bg-[oklch(0.14_0.02_264)] px-5 py-12 text-white sm:px-8 md:py-16">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-10 opacity-[0.35]"
        style={{
          backgroundImage:
            "linear-gradient(to right, rgba(255,255,255,0.06) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.06) 1px, transparent 1px)",
          backgroundSize: "56px 56px",
        }}
      />
      <span
        aria-hidden
        className="ambient-glow left-[10%] top-[-10%] h-[320px] w-[320px] bg-[color-mix(in_oklab,var(--accent-vivid)_60%,transparent)]"
      />

      <header className="relative max-w-2xl">
        <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-white/50">
          Tech Concept Showcase
        </p>
        <h2 className="font-serif-display mt-3 text-3xl leading-tight text-white md:text-4xl">
          Engineered concepts, measured in specs
        </h2>
        <p className="mt-3 text-sm leading-relaxed text-white/60 md:text-base">
          A modular look at the systems we cover — each block is a live area of research, tested
          against real production workloads.
        </p>
      </header>

      <div className="relative mt-9 grid gap-4 md:grid-cols-3 md:grid-rows-2">
        <article className={`${cardBase} md:col-span-2 md:row-span-2 flex flex-col justify-between`}>
          <div className="overflow-hidden rounded-xl border border-white/10">
            <img
              src="https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1400&q=80"
              alt="Close-up of a circuit board with precision components"
              width={1400}
              height={900}
              loading="lazy"
              className="aspect-[16/9] w-full object-cover opacity-90 transition-transform duration-700 ease-out group-hover:scale-105"
            />
          </div>
          <div className="mt-5">
            <div className="flex flex-wrap gap-2">
              <span className={specTag}>Edge inference</span>
              <span className={specTag}>&lt; 40 ms p95</span>
              <span className={specTag}>8B params</span>
            </div>
            <h3 className="font-serif-display mt-4 text-2xl text-white">
              Silicon-close AI runtimes
            </h3>
            <p className="mt-2 max-w-lg text-sm leading-relaxed text-white/60">
              Quantized models running next to the request, not across an ocean. We break down the
              memory maths, the batching trade-offs and the real latency wins.
            </p>
            <Link
              to="/blog"
              className="mt-5 inline-flex items-center gap-1.5 rounded-full border border-white/20 px-4 py-2 text-xs font-semibold uppercase tracking-[0.14em] text-white/80 transition-all duration-300 hover:border-white/50 hover:text-white"
            >
              Explore breakdown
              <ArrowUpRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-0.5" />
            </Link>
          </div>
        </article>

        {[
          {
            icon: Gauge,
            title: "Performance budgets",
            spec: "LCP 1.2s",
            copy: "Shipping fast pages with hard numbers, not vibes.",
          },
          {
            icon: ShieldCheck,
            title: "Zero-trust posture",
            spec: "mTLS · SSO",
            copy: "Identity at every hop, from device to database.",
          },
        ].map(({ icon: Icon, title, spec, copy }) => (
          <article key={title} className={cardBase}>
            <div className="flex items-center justify-between">
              <Icon className="h-5 w-5 text-[color-mix(in_oklab,var(--accent-vivid)_70%,white)]" />
              <span className={specTag}>{spec}</span>
            </div>
            <h3 className="mt-4 text-lg font-semibold text-white">{title}</h3>
            <p className="mt-1.5 text-sm leading-relaxed text-white/55">{copy}</p>
          </article>
        ))}
      </div>

      <div className="relative mt-4 grid gap-4 sm:grid-cols-3">
        {[
          { icon: Layers, label: "Architecture", value: "12 deep dives" },
          { icon: Cpu, label: "Hardware", value: "9 teardowns" },
          { icon: Sparkles, label: "Research", value: "Weekly notes" },
        ].map(({ icon: Icon, label, value }) => (
          <div
            key={label}
            className="group flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-4 backdrop-blur-xl transition-colors duration-300 hover:border-white/25"
          >
            <Icon className="h-4 w-4 text-white/60 transition-colors group-hover:text-white" />
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-white/40">
                {label}
              </p>
              <p className="text-sm font-semibold text-white/85">{value}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
