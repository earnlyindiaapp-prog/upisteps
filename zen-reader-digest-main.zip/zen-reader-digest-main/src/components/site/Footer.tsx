import { Link } from "@tanstack/react-router";
import { Instagram, Send, Twitter, Youtube } from "lucide-react";
import { Logo, Wordmark } from "./Logo";

const socials = [
  { href: "https://www.youtube.com/@EarnlyIndiaOfficial", label: "YouTube", Icon: Youtube },
  { href: "https://www.instagram.com/uniquepieceoffical?igsi=aXcxcjN1ZXE1Ym50", label: "Instagram", Icon: Instagram },
  { href: "https://x.com/EarnlyIndia_", label: "Twitter (X)", Icon: Twitter },
  { href: "https://t.me/EarnlyIndiaOfficial", label: "Telegram", Icon: Send },
];

const groups = [
  {
    title: "Sections",
    links: [
      { to: "/", label: "Home" },
      { to: "/blog", label: "Blog" },
      { to: "/playground", label: "Playground" },
    ],
  },
  {
    title: "Company",
    links: [
      { to: "/about", label: "About Us" },
      { to: "/contact", label: "Contact Us" },
    ],
  },
  {
    title: "Legal",
    links: [
      { to: "/privacy-policy", label: "Privacy Policy" },
      { to: "/terms-and-conditions", label: "Terms & Conditions" },
    ],
  },
] as const;

export function Footer() {
  return (
    <footer className="mt-20 border-t border-border bg-secondary/50">
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
        <div className="grid gap-10 sm:grid-cols-2 md:grid-cols-4">
          <div>
            <div className="group flex items-center gap-2.5">
              <Logo className="h-8 w-8" />
              <Wordmark />
            </div>
            <p className="mt-3 max-w-xs text-sm leading-relaxed text-muted-foreground">
              Clear, practical technology writing for engineers and the people who work with them.
            </p>
            <ul className="mt-5 flex items-center gap-2">
              {socials.map(({ href, label, Icon }) => (
                <li key={label}>
                  <a
                    href={href}
                    target="_blank"
                    rel="noreferrer"
                    aria-label={label}
                    className="icon-pulse inline-flex h-9 w-9 items-center justify-center rounded-full border border-border text-muted-foreground transition-all duration-300 hover:-translate-y-0.5 hover:border-[color-mix(in_oklab,var(--accent-vivid)_50%,transparent)] hover:text-accent-vivid hover:shadow-[var(--shadow-glow)]"
                  >
                    <Icon className="h-4 w-4" aria-hidden />
                  </a>
                </li>
              ))}
            </ul>
          </div>
          {groups.map((group) => (
            <div key={group.title}>
              <h2 className="text-sm font-semibold tracking-tight">{group.title}</h2>
              <ul className="mt-3 space-y-2">
                {group.links.map((l) => (
                  <li key={l.to}>
                    <Link
                      to={l.to}
                      className="text-sm text-muted-foreground transition-colors hover:text-accent-vivid"
                    >
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-10 border-t border-border pt-6 text-xs text-muted-foreground">
          © {new Date().getFullYear()} UPISTEPS. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
