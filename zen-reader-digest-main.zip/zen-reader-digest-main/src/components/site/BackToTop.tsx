import { ArrowUp } from "lucide-react";
import { useEffect, useState } from "react";

export function BackToTop() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 420);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <button
      type="button"
      aria-label="Back to top"
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      className={`fixed bottom-6 right-5 z-50 inline-flex h-12 w-12 items-center justify-center rounded-full border border-[color-mix(in_oklab,var(--accent-vivid)_45%,transparent)] bg-background/70 text-accent-vivid shadow-[var(--shadow-glow)] backdrop-blur-xl transition-all duration-300 ease-out hover:scale-110 hover:bg-background focus-visible:scale-110 ${
        visible
          ? "pointer-events-auto translate-y-0 scale-100 opacity-100"
          : "pointer-events-none translate-y-4 scale-75 opacity-0"
      }`}
    >
      <ArrowUp className="h-5 w-5 motion-safe:animate-[float-soft_2.6s_ease-in-out_infinite]" aria-hidden />
    </button>
  );
}
