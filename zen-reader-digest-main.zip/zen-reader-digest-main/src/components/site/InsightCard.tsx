import { useEffect, useState, type FormEvent } from "react";
import { Mail, Quote, Send, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { Reveal } from "@/components/site/Reveal";

/**
 * A sleek "Tech Quote & Insight of the Day" glassmorphism card with an
 * inline Instant-Update newsletter input. Rotates quotes automatically
 * and on click. The quote list is easy to edit below.
 */
const INSIGHTS: { text: string; author: string }[] = [
  {
    text: "The best way to predict the future is to invent it.",
    author: "Alan Kay",
  },
  {
    text: "Any sufficiently advanced technology is indistinguishable from magic.",
    author: "Arthur C. Clarke",
  },
  {
    text: "Simplicity is the soul of efficiency.",
    author: "Austin Freeman",
  },
  {
    text: "Programs must be written for people to read, and only incidentally for machines to execute.",
    author: "Harold Abelson",
  },
  {
    text: "The Web is the most impactful technology since the book.",
    author: "UPISTEPS Editorial",
  },
  {
    text: "First, solve the problem. Then, write the code.",
    author: "John Johnson",
  },
  {
    text: "Talk is cheap. Show me the code.",
    author: "Linus Torvalds",
  },
  {
    text: "Performance is a feature. Ship the fast version.",
    author: "UPISTEPS Editorial",
  },
];

function todaysIndex() {
  // Deterministic "insight of the day" based on the date.
  const day = Math.floor(Date.now() / 86_400_000);
  return day % INSIGHTS.length;
}

export function InsightCard() {
  const [index, setIndex] = useState(todaysIndex);
  const [email, setEmail] = useState("");

  // Rotate the quote every 9 seconds.
  useEffect(() => {
    const id = window.setInterval(() => {
      setIndex((i) => (i + 1) % INSIGHTS.length);
    }, 9000);
    return () => window.clearInterval(id);
  }, []);

  const insight = INSIGHTS[index] ?? INSIGHTS[0]!;

  function onSubscribe(e: FormEvent) {
    e.preventDefault();
    const value = email.trim();
    if (!value) {
      toast.error("Enter your email to get instant updates");
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      toast.error("That email doesn't look right");
      return;
    }
    setEmail("");
    toast.success("You're on the instant list", {
      description: `Breaking tech updates will land in ${value}.`,
    });
  }

  return (
    <section className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
      <Reveal>
        <div className="relative overflow-hidden rounded-3xl border border-[color-mix(in_oklab,var(--accent-vivid)_22%,var(--border))] bg-card/50 p-5 shadow-[var(--shadow-elegant)] backdrop-blur-2xl sm:p-7">
          {/* ambient glows */}
          <span
            aria-hidden
            className="ambient-glow right-[-30%] top-[-60%] h-72 w-72 bg-[color-mix(in_oklab,var(--accent-vivid)_40%,transparent)]"
          />
          <span
            aria-hidden
            className="ambient-glow left-[-30%] bottom-[-60%] h-72 w-72 bg-[color-mix(in_oklab,oklch(0.65_0.2_310)_32%,transparent)]"
          />

          <div className="relative grid gap-6 lg:grid-cols-[1.15fr_1fr] lg:items-center">
            {/* Quote / Insight of the day */}
            <div className="relative">
              <span className="icon-pulse inline-flex items-center gap-2 rounded-full border border-[color-mix(in_oklab,var(--accent-vivid)_40%,transparent)] bg-background/70 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.2em] text-accent-vivid">
                <Sparkles className="h-3 w-3" aria-hidden />
                Insight of the Day
              </span>

              <div className="mt-4 flex gap-3">
                <Quote
                  className="mt-1 h-7 w-7 shrink-0 text-[color-mix(in_oklab,var(--accent-vivid)_60%,transparent)]"
                  aria-hidden
                />
                <div key={index} className="motion-safe:animate-[fade-up_0.6s_ease-out_both]">
                  <p className="font-serif-display text-xl leading-snug text-foreground md:text-2xl">
                    {insight.text}
                  </p>
                  <p className="mt-2 text-sm font-semibold text-muted-foreground">
                    — {insight.author}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIndex((i) => (i + 1) % INSIGHTS.length)}
                className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-accent-vivid transition-opacity hover:opacity-80"
              >
                <Sparkles className="h-3.5 w-3.5" aria-hidden />
                Next insight
              </button>
            </div>

            {/* divider */}
            <div className="hidden lg:block">
              <span
                aria-hidden
                className="mx-auto block h-24 w-px bg-[linear-gradient(180deg,transparent,var(--border),transparent)]"
              />
            </div>

            {/* Instant update subscriber */}
            <div className="lg:border-l lg:border-border/60 lg:pl-6">
              <h3 className="text-lg font-bold text-foreground">Get Instant Updates</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                Drop your email and we'll ping you the moment a story breaks.
              </p>

              <form
                onSubmit={onSubscribe}
                className="mt-4 flex flex-col gap-2.5 sm:flex-row"
              >
                <label htmlFor="insight-email" className="sr-only">
                  Email address
                </label>
                <div className="relative flex-1">
                  <Mail
                    className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
                    aria-hidden
                  />
                  <input
                    id="insight-email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@company.com"
                    className="h-12 w-full rounded-full border border-input bg-background/80 pl-10 pr-4 text-sm outline-none transition-all duration-300 placeholder:text-muted-foreground focus:border-[color-mix(in_oklab,var(--accent-vivid)_60%,transparent)] focus:ring-2 focus:ring-ring/25"
                  />
                </div>
                <button
                  type="submit"
                  className="btn-premium inline-flex h-12 items-center justify-center gap-2 rounded-full px-6 text-sm font-semibold transition-transform duration-200 active:scale-95"
                >
                  <Send className="h-4 w-4" aria-hidden />
                  Notify me
                </button>
              </form>
              <p className="mt-2 text-xs text-muted-foreground">
                No spam. One-click unsubscribe.
              </p>
            </div>
          </div>
        </div>
      </Reveal>
    </section>
  );
}
