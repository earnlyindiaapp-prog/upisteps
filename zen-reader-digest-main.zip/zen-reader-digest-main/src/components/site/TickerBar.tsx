import { Link } from "@tanstack/react-router";
import { Flame } from "lucide-react";

const items = [
  "Small language models cut inference bills by 90%",
  "Passkeys hit mainstream adoption across major browsers",
  "Edge runtimes reshape how teams deploy APIs",
  "GPU spot pricing falls for the third quarter running",
  "Rust creeps into frontend build toolchains",
  "Post-quantum TLS lands in production stacks",
  "On-device AI pushes battery engineering forward",
];

export function TickerBar() {
  return (
    <div className="relative z-30 overflow-hidden border-b border-border/70 bg-[linear-gradient(90deg,color-mix(in_oklab,var(--accent-vivid)_12%,transparent),transparent_45%,color-mix(in_oklab,oklch(0.65_0.2_310)_12%,transparent))] backdrop-blur-xl">
      <div className="mx-auto flex h-10 max-w-6xl items-center gap-3 px-4 sm:px-6">
        <span className="icon-pulse inline-flex shrink-0 items-center gap-1.5 rounded-full border border-[color-mix(in_oklab,var(--accent-vivid)_40%,transparent)] bg-background/70 px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.18em] text-accent-vivid">
          <Flame className="h-3 w-3" aria-hidden />
          Trending
        </span>
        <div className="group relative flex-1 overflow-hidden [mask-image:linear-gradient(90deg,transparent,black_6%,black_94%,transparent)]">
          <div className="flex w-max gap-8 motion-safe:animate-[marquee_38s_linear_infinite] group-hover:[animation-play-state:paused]">
            {[0, 1].map((dup) => (
              <div key={dup} className="flex shrink-0 gap-8" aria-hidden={dup === 1}>
                {items.map((t) => (
                  <Link
                    key={t}
                    to="/blog"
                    search={{ q: "" }}
                    className="whitespace-nowrap text-xs text-muted-foreground transition-colors hover:text-accent-vivid"
                  >
                    <span className="mr-2 text-accent-vivid">•</span>
                    {t}
                  </Link>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
