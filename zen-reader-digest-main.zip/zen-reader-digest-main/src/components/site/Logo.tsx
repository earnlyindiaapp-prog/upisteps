export function Logo({ className = "h-8 w-8" }: { className?: string }) {
  return (
    <span
      className={`inline-flex items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-[0_6px_16px_-6px_var(--primary)] transition-transform duration-300 group-hover:scale-105 ${className}`}
      aria-hidden
    >
      <svg viewBox="0 0 24 24" fill="none" className="h-[60%] w-[60%]">
        <path
          d="M4 17.5 9 12l3.5 3.5L20 7"
          stroke="currentColor"
          strokeWidth="2.2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M15 7h5v5"
          stroke="currentColor"
          strokeWidth="2.2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </span>
  );
}

export function Wordmark() {
  return (
    <span className="font-display text-lg font-extrabold uppercase tracking-[0.14em]">
      UPISTEPS
    </span>
  );
}
