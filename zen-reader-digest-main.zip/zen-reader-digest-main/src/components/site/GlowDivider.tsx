export function GlowDivider({ className = "" }: { className?: string }) {
  return (
    <div className={`relative mx-auto max-w-6xl px-4 sm:px-6 ${className}`} aria-hidden>
      <div className="glow-divider" />
    </div>
  );
}
