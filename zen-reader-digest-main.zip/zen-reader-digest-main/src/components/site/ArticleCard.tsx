import { Link } from "@tanstack/react-router";
import { Clock } from "lucide-react";
import { formatDate, type Article } from "@/lib/articles";

export function ArticleCard({ article }: { article: Article }) {
  return (
    <article className="group relative flex h-full flex-col overflow-hidden rounded-2xl border border-border bg-card/60 shadow-[inset_0_1px_0_0_color-mix(in_oklab,var(--foreground)_6%,transparent)] backdrop-blur-xl transition-all duration-500 ease-out motion-safe:hover:-translate-y-2.5 motion-safe:hover:scale-[1.03] hover:border-[color-mix(in_oklab,var(--accent-vivid)_55%,transparent)] hover:shadow-[var(--shadow-lift)]">
      <Link
        to="/blog/$slug"
        params={{ slug: article.slug }}
        className="block overflow-hidden bg-muted"
      >
        <img
          src={article.image}
          alt={article.title}
          width={1200}
          height={675}
          loading="lazy"
          className="aspect-[16/9] w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.07]"
        />
      </Link>
      <div className="flex flex-1 flex-col p-5">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.14em] text-accent-vivid">
          {article.category}
        </div>
        <h3 className="font-serif-display mt-2 text-xl leading-snug">
          <Link
            to="/blog/$slug"
            params={{ slug: article.slug }}
            className="transition-colors duration-300 hover:text-accent-vivid"
          >
            {article.title}
          </Link>
        </h3>
        <p className="mt-2 line-clamp-3 flex-1 text-sm leading-relaxed text-muted-foreground">
          {article.excerpt}
        </p>
        <div className="mt-4 flex items-center gap-2 text-xs text-muted-foreground">
          <time dateTime={article.date}>{formatDate(article.date)}</time>
          <span aria-hidden>·</span>
          <span className="inline-flex items-center gap-1">
            <Clock className="h-3.5 w-3.5" aria-hidden />
            {article.readingTime}
          </span>
        </div>
      </div>
    </article>
  );
}
