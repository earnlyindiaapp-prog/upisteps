import { toast } from "sonner";

export function CategoryTabs({
  categories,
  active,
  onChange,
}: {
  categories: string[];
  active: string;
  onChange: (c: string) => void;
}) {
  return (
    <div className="flex flex-wrap gap-2" role="tablist" aria-label="Filter articles by category">
      {categories.map((c) => {
        const isActive = c === active;
        return (
          <button
            key={c}
            type="button"
            role="tab"
            aria-selected={isActive}
            onClick={() => {
              onChange(c);
              toast.success(c === "All" ? "Showing all articles" : `Filtered: ${c}`, {
                description: "Article grid updated.",
              });
            }}
            className={`rounded-full border px-4 py-2 text-xs font-semibold transition-all duration-300 ease-out hover:-translate-y-0.5 sm:text-sm ${
              isActive
                ? "border-transparent bg-[image:var(--gradient-accent)] text-primary-foreground shadow-[var(--shadow-glow)]"
                : "border-border bg-background/60 text-muted-foreground backdrop-blur hover:border-[color-mix(in_oklab,var(--accent-vivid)_45%,transparent)] hover:text-accent-vivid"
            }`}
          >
            {c}
          </button>
        );
      })}
    </div>
  );
}
