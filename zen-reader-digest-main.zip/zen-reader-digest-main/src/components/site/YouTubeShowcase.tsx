import { useState } from "react";
import { Play, Volume2, VolumeX, ExternalLink } from "lucide-react";
import { Reveal } from "@/components/site/Reveal";

/**
 * ─────────────────────────────────────────────────────────────
 *  YOUTUBE VIDEO CONFIG  (change this one value to swap the video)
 * ─────────────────────────────────────────────────────────────
 *  Paste any YouTube video ID here (the part after `v=` in a
 *  watch URL, or the last path segment of a youtu.be/ link).
 *  Example: https://www.youtube.com/watch?v=dQw4w9WgXcQ  ->  dQw4w9WgXcQ
 *
 *  Channel: https://www.youtube.com/@EarnlyIndiaOfficial
 */
export const YOUTUBE_VIDEO_ID = "dQw4w9WgXcQ";
/** Optional title + description shown beside the player. */
const VIDEO_TITLE = "Featured: Earnly India Official";
const VIDEO_DESC =
  "The main video from the Earnly India Official channel. Press play to watch inline, or open it on YouTube.";
const CHANNEL_URL = "https://www.youtube.com/@EarnlyIndiaOfficial";

const THUMB = `https://i.ytimg.com/vi/${YOUTUBE_VIDEO_ID}/maxresdefault.jpg`;
const FALLBACK_THUMB = `https://i.ytimg.com/vi/${YOUTUBE_VIDEO_ID}/hqdefault.jpg`;

export function YouTubeShowcase() {
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(true);

  // Autoplay-muted embed (allowed by browsers) OR interactive embed with sound.
  const embedSrc = `https://www.youtube-nocookie.com/embed/${YOUTUBE_VIDEO_ID}?autoplay=1&rel=0&modestbranding=1&mute=${
    muted ? 1 : 0
  }`;

  return (
    <div className="relative overflow-hidden rounded-3xl border border-border/70 bg-card/60 p-4 shadow-[var(--shadow-elegant)] backdrop-blur-xl sm:p-6">
      {/* ambient glow */}
      <div
        aria-hidden
        className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-[radial-gradient(circle,color-mix(in_oklab,var(--accent-vivid)_28%,transparent),transparent_70%)] blur-2xl"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -bottom-24 -left-24 h-72 w-72 rounded-full bg-[radial-gradient(circle,color-mix(in_oklab,var(--accent-vivid)_18%,transparent),transparent_70%)] blur-2xl"
      />

      <div className="relative grid gap-6 lg:grid-cols-[1.6fr_1fr] lg:items-center">
        {/* Player / poster */}
        <div className="group relative aspect-video w-full overflow-hidden rounded-2xl border border-border/70 bg-black shadow-[var(--shadow-glow)]">
          {playing ? (
            <iframe
              className="absolute inset-0 h-full w-full"
              src={embedSrc}
              title={VIDEO_TITLE}
              loading="lazy"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
              referrerPolicy="strict-origin-when-cross-origin"
            />
          ) : (
            <button
              type="button"
              onClick={() => setPlaying(true)}
              className="absolute inset-0 h-full w-full"
              aria-label={`Play video: ${VIDEO_TITLE}`}
            >
              {/* thumbnail */}
              <img
                src={THUMB}
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = FALLBACK_THUMB;
                }}
                alt={VIDEO_TITLE}
                loading="lazy"
                className="h-full w-full object-cover opacity-85 transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />

              {/* play button */}
              <span className="absolute inset-0 flex items-center justify-center">
                <span className="relative flex h-20 w-20 items-center justify-center rounded-full bg-white/15 backdrop-blur-md ring-1 ring-white/40 transition-all duration-300 group-hover:scale-110 group-hover:bg-white/25">
                  <span className="absolute inset-0 animate-ping rounded-full bg-white/15" />
                  <Play className="h-8 w-8 translate-x-0.5 fill-white text-white" />
                </span>
              </span>

              <span className="absolute bottom-3 left-4 flex items-center gap-1.5 text-xs font-medium text-white/90">
                {muted ? <VolumeX className="h-3.5 w-3.5" /> : <Volume2 className="h-3.5 w-3.5" />}
                {muted ? "Autoplay muted — click to play with sound" : "Click to play"}
              </span>
            </button>
          )}
        </div>

        {/* Copy + controls */}
        <div className="flex flex-col gap-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent-vivid">
              Watch on YouTube
            </p>
            <h3 className="font-serif-display mt-2 text-2xl text-foreground md:text-3xl">
              {VIDEO_TITLE}
            </h3>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{VIDEO_DESC}</p>
          </div>

          <div className="flex flex-wrap gap-3">
            {!playing && (
              <button
                type="button"
                onClick={() => {
                  setMuted(false);
                  setPlaying(true);
                }}
                className="btn-premium inline-flex h-11 items-center gap-2 rounded-full px-6 text-sm font-semibold"
              >
                <Volume2 className="h-4 w-4" aria-hidden />
                Play with sound
              </button>
            )}

            {!playing && (
              <button
                type="button"
                onClick={() => {
                  setMuted(true);
                  setPlaying(true);
                }}
                className="inline-flex h-11 items-center gap-2 rounded-full border border-input bg-background px-6 text-sm font-semibold transition-all duration-300 hover:-translate-y-0.5 hover:border-[color-mix(in_oklab,var(--accent-vivid)_50%,transparent)] hover:text-accent-vivid hover:shadow-[var(--shadow-glow)]"
              >
                <VolumeX className="h-4 w-4" aria-hidden />
                Autoplay (muted)
              </button>
            )}

            {playing && (
              <button
                type="button"
                onClick={() => setMuted((m) => !m)}
                className="inline-flex h-11 items-center gap-2 rounded-full border border-input bg-background px-6 text-sm font-semibold transition-all duration-300 hover:-translate-y-0.5 hover:border-[color-mix(in_oklab,var(--accent-vivid)_50%,transparent)] hover:text-accent-vivid"
              >
                {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                {muted ? "Unmute" : "Mute"}
              </button>
            )}

            <a
              href={`${CHANNEL_URL}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex h-11 items-center gap-2 rounded-full border border-input bg-background px-6 text-sm font-semibold transition-all duration-300 hover:-translate-y-0.5 hover:border-[color-mix(in_oklab,var(--accent-vivid)_50%,transparent)] hover:text-accent-vivid"
            >
              <ExternalLink className="h-4 w-4" aria-hidden />
              Open channel
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

/** Section wrapper used on the homepage. */
export function YouTubeShowcaseSection() {
  return (
    <section className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
      <Reveal>
        <h2 className="font-serif-display text-gradient mb-6 text-3xl md:text-4xl">
          Featured Video
        </h2>
        <YouTubeShowcase />
      </Reveal>
    </section>
  );
}
