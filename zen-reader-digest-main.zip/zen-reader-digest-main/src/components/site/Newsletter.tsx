import { Mail, Sparkles } from "lucide-react";
import { useState, type FormEvent } from "react";
import { toast } from "sonner";

export function Newsletter() {
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const value = email.trim();
    if (!value) {
      toast.error("Enter your email to subscribe");
      return;
    }
    setDone(true);
    setEmail("");
    toast.success("You're subscribed", {
      description: `Daily Tech Steps will land in ${value} each morning.`,
    });
  }

  return (
    <section
      id="newsletter"
      className="relative overflow-hidden rounded-3xl border border-[color-mix(in_oklab,var(--accent-vivid)_28%,var(--border))] bg-[linear-gradient(135deg,color-mix(in_oklab,var(--accent-vivid)_12%,transparent),transparent_55%,color-mix(in_oklab,oklch(0.65_0.2_310)_14%,transparent))] p-8 text-center backdrop-blur-xl md:p-14"
    >
      <span
        aria-hidden
        className="ambient-glow left-1/2 top-[-40%] h-72 w-72 -translate-x-1/2 bg-[color-mix(in_oklab,var(--accent-vivid)_50%,transparent)]"
      />
      <div className="relative">
        <span className="icon-pulse inline-flex items-center gap-2 rounded-full border border-[color-mix(in_oklab,var(--accent-vivid)_40%,transparent)] px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.2em] text-accent-vivid">
          <Sparkles className="h-3.5 w-3.5" aria-hidden />
          Daily digest
        </span>
        <h2 className="text-gradient mx-auto mt-5 max-w-2xl text-3xl md:text-4xl">
          Get Daily Tech Steps in your Inbox
        </h2>
        <p className="mx-auto mt-3 max-w-xl text-sm leading-relaxed text-muted-foreground md:text-base">
          One short email each morning: the story that matters, why it matters, and what to do
          about it. No hype, no spam, unsubscribe in one click.
        </p>

        <form
          onSubmit={onSubmit}
          className="mx-auto mt-7 flex w-full max-w-lg flex-col gap-3 sm:flex-row"
        >
          <label htmlFor="newsletter-email" className="sr-only">
            Email address
          </label>
          <div className="relative flex-1">
            <Mail
              className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
              aria-hidden
            />
            <input
              id="newsletter-email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@company.com"
              className="h-12 w-full rounded-full border border-input bg-background/80 pl-10 pr-4 text-sm outline-none transition-all duration-300 placeholder:text-muted-foreground focus:border-[color-mix(in_oklab,var(--accent-vivid)_60%,transparent)] focus:ring-2 focus:ring-ring/25"
            />
          </div>
          <button
            type="submit"
            className="btn-premium inline-flex h-12 items-center justify-center rounded-full px-7 text-sm font-semibold transition-transform duration-200 active:scale-95"
          >
            Subscribe
          </button>
        </form>
        <p className="mt-3 text-xs text-muted-foreground" aria-live="polite">
          {done ? "You're on the list — check your inbox to confirm." : "Join 24,000+ engineers."}
        </p>
      </div>
    </section>
  );
}
