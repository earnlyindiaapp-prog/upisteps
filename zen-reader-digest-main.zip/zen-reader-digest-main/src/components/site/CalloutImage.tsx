type Callout = {
  /** percentage position of the anchor dot */
  x: number;
  y: number;
  label: string;
  value: string;
  /** which way the dotted line runs */
  side?: "left" | "right";
};

export function CalloutImage({
  src,
  alt,
  callouts,
  className = "",
}: {
  src: string;
  alt: string;
  callouts: Callout[];
  className?: string;
}) {
  return (
    <div
      className={`group relative overflow-hidden rounded-3xl border border-border bg-card/40 backdrop-blur-xl ${className}`}
    >
      <img
        src={src}
        alt={alt}
        width={1600}
        height={1067}
        className="aspect-[4/3] w-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
      />

      <div aria-hidden className="pointer-events-none absolute inset-0 hidden sm:block">
        {callouts.map((c) => {
          const side = c.side ?? "right";
          return (
            <div key={c.label} style={{ left: `${c.x}%`, top: `${c.y}%` }} className="absolute">
              <span className="absolute -left-1 -top-1 block h-2 w-2 rounded-full bg-[var(--accent-vivid)] shadow-[0_0_0_4px_color-mix(in_oklab,var(--accent-vivid)_25%,transparent)]" />
              <span
                className={`absolute top-0 h-px w-14 border-t border-dashed border-[color-mix(in_oklab,var(--accent-vivid)_70%,transparent)] ${
                  side === "right" ? "left-0" : "right-0"
                }`}
              />
              <span
                className={`absolute top-[-14px] whitespace-nowrap rounded-full border border-[color-mix(in_oklab,var(--accent-vivid)_35%,transparent)] bg-background/70 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-foreground backdrop-blur-md ${
                  side === "right" ? "left-[3.75rem]" : "right-[3.75rem]"
                }`}
              >
                {c.label}
                <span className="ml-1.5 text-accent-vivid">{c.value}</span>
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
