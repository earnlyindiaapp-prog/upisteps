import { Link } from "@tanstack/react-router";
import { ArrowRight, ChevronLeft, ChevronRight, Clock } from "lucide-react";
import { useEffect, useState } from "react";
import { formatDate, type Article } from "@/lib/articles";

export function FeaturedSlider({ items }: { items: Article[] }) {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    if (paused || items.length < 2) return;
    const id = window.setInterval(() => setIndex((i) => (i + 1) % items.length), 6000);
    return () => window.clearInterval(id);
  }, [paused, items.length]);

  const go = (dir: number) => setIndex((i) => (i + dir + items.length) % items.length);

  return (
    <div
      className="relative"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      aria-roledescription="carousel"
      aria-label="Featured articles"
    >
      <div className="relative overflow-hidden rounded-3xl border border-[color-mix(in_oklab,var(--accent-vivid)_25%,var(--border))] bg-card/70 backdrop-blur-xl shadow-[var(--shadow-lift)]">
        <div
          className="flex transition-transform duration-700 ease-[cubic-bezier(0.22,1,0.36,1)]"
          style={{ transform: `translateX(-${index * 100}%)` }}
        >
          {items.map((a, i) => (
            <article
              key={a.slug}
              className="grid w-full shrink-0 gap-6 p-5 md:grid-cols-2 md:items-center md:p-8"
              aria-hidden={i !== index}
            >
              <Link
                to="/blog/$slug"
                params={{ slug: a.slug }}
                tabIndex={i === index ? 0 : -1}
                className="group relative block overflow-hidden rounded-2xl"
              >
                <img
                  src={a.image}
                  alt={a.title}
                  width={1600}
                  height={1000}
                  loading={i === 0 ? "eager" : "lazy"}
                  className="aspect-[16/10] w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.06]"
                />
              </Link>
              <div>
                <span className="inline-flex rounded-full border border-[color-mix(in_oklab,var(--accent-vivid)_40%,transparent)] px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-accent-vivid">
                  {a.category}
                </span>
                <h2 className="font-serif-display mt-4 text-2xl leading-tight md:text-4xl">
                  <Link
                    to="/blog/$slug"
                    params={{ slug: a.slug }}
                    tabIndex={i === index ? 0 : -1}
                    className="transition-colors duration-300 hover:text-accent-vivid"
                  >
                    {a.title}
                  </Link>
                </h2>
                <p className="mt-3 line-clamp-3 text-sm leading-relaxed text-muted-foreground md:text-base">
                  {a.excerpt}
                </p>
                <div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                  <span>{a.author}</span>
                  <span aria-hidden>·</span>
                  <time dateTime={a.date}>{formatDate(a.date)}</time>
                  <span aria-hidden>·</span>
                  <span className="inline-flex items-center gap-1">
                    <Clock className="h-3.5 w-3.5" aria-hidden />
                    {a.readingTime}
                  </span>
                </div>
                <Link
                  to="/blog/$slug"
                  params={{ slug: a.slug }}
                  tabIndex={i === index ? 0 : -1}
                  className="btn-premium group mt-6 inline-flex h-11 items-center gap-2 rounded-full px-6 text-sm font-semibold"
                >
                  Read the breakdown
                  <ArrowRight
                    className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1"
                    aria-hidden
                  />
                </Link>
              </div>
            </article>
          ))}
        </div>
      </div>

      <div className="mt-5 flex items-center justify-center gap-4">
        <button
          type="button"
          aria-label="Previous featured article"
          onClick={() => go(-1)}
          className="icon-pulse inline-flex h-10 w-10 items-center justify-center rounded-full border border-border bg-background/70 text-muted-foreground backdrop-blur transition-all duration-300 hover:scale-110 hover:border-[color-mix(in_oklab,var(--accent-vivid)_50%,transparent)] hover:text-accent-vivid"
        >
          <ChevronLeft className="h-4 w-4" aria-hidden />
        </button>
        <div className="flex items-center gap-2">
          {items.map((a, i) => (
            <button
              key={a.slug}
              type="button"
              aria-label={`Go to slide ${i + 1}`}
              aria-current={i === index}
              onClick={() => setIndex(i)}
              className={`h-1.5 rounded-full transition-all duration-500 ${
                i === index
                  ? "w-8 bg-[var(--accent-vivid)] shadow-[var(--shadow-glow)]"
                  : "w-2.5 bg-border hover:bg-muted-foreground"
              }`}
            />
          ))}
        </div>
        <button
          type="button"
          aria-label="Next featured article"
          onClick={() => go(1)}
          className="icon-pulse inline-flex h-10 w-10 items-center justify-center rounded-full border border-border bg-background/70 text-muted-foreground backdrop-blur transition-all duration-300 hover:scale-110 hover:border-[color-mix(in_oklab,var(--accent-vivid)_50%,transparent)] hover:text-accent-vivid"
        >
          <ChevronRight className="h-4 w-4" aria-hidden />
        </button>
      </div>
    </div>
  );
}
