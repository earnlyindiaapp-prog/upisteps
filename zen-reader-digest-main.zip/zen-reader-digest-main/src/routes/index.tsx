import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { useMemo, useState } from "react";
import { articles } from "@/lib/articles";
import { ArticleCard } from "@/components/site/ArticleCard";
import { AdSlot } from "@/components/site/AdSlot";
import { Reveal } from "@/components/site/Reveal";
import { GlowDivider } from "@/components/site/GlowDivider";
import { FeaturedSlider } from "@/components/site/FeaturedSlider";
import { CategoryTabs } from "@/components/site/CategoryTabs";
import { Newsletter } from "@/components/site/Newsletter";
import { FaqSection } from "@/components/site/FaqSection";
import { BentoShowcase } from "@/components/site/BentoShowcase";
import { CalloutImage } from "@/components/site/CalloutImage";
import { YouTubeShowcaseSection } from "@/components/site/YouTubeShowcase";
import { InsightCard } from "@/components/site/InsightCard";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "UPISTEPS — Practical Tech Writing for Engineers" },
      {
        name: "description",
        content:
          "Clear, fast-loading articles on AI, web development, cloud infrastructure and security. No hype, just what works in production.",
      },
      { property: "og:title", content: "UPISTEPS — Practical Tech Writing for Engineers" },
      {
        property: "og:description",
        content:
          "Clear, fast-loading articles on AI, web development, cloud infrastructure and security.",
      },
    ],
  }),
  component: Home,
});

const heroImage =
  "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1600&q=80";

function Home() {
  const [category, setCategory] = useState("All");

  const categories = useMemo(
    () => ["All", ...Array.from(new Set(articles.map((a) => a.category)))],
    [],
  );

  const filtered = useMemo(
    () => (category === "All" ? articles : articles.filter((a) => a.category === category)),
    [category],
  );

  const featured = articles.slice(0, 3);

  return (
    <>
      <section className="relative overflow-hidden bg-[linear-gradient(180deg,color-mix(in_oklab,var(--accent-vivid)_7%,transparent),transparent_70%)]">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-16 sm:px-6 md:py-24 lg:grid-cols-[1.1fr_1fr]">
          <Reveal>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent-vivid">
              Technology, explained plainly
            </p>
            <h1 className="text-gradient mt-4 max-w-3xl text-4xl font-extrabold leading-[1.05] tracking-tight md:text-5xl">
              Engineering insight without the noise.
            </h1>

            <p className="mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground md:text-lg">
              UPISTEPS covers artificial intelligence, web performance, cloud infrastructure and
              security — written for people who ship. Every article is short, specific and free of
              marketing language.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                to="/blog"
                className="btn-premium group inline-flex h-12 items-center gap-2 rounded-full px-7 text-sm font-semibold"
              >
                Read the blog
                <ArrowRight
                  className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1"
                  aria-hidden
                />
              </Link>
              <Link
                to="/about"
                className="inline-flex h-12 items-center rounded-full border border-input bg-background px-7 text-sm font-semibold transition-all duration-300 hover:-translate-y-0.5 hover:border-[color-mix(in_oklab,var(--accent-vivid)_50%,transparent)] hover:text-accent-vivid hover:shadow-[var(--shadow-glow)]"
              >
                About UPISTEPS
              </Link>
            </div>
          </Reveal>

          <Reveal delay={120}>
            <CalloutImage
              src={heroImage}
              alt="Modern minimalist developer workspace with a laptop and clean desk setup"
              callouts={[
                { x: 22, y: 26, label: "Build", value: "1.2s LCP", side: "right" },
                { x: 74, y: 58, label: "Runtime", value: "Edge", side: "left" },
                { x: 38, y: 80, label: "Payload", value: "94 KB", side: "right" },
              ]}
            />
          </Reveal>
        </div>
      </section>

      <GlowDivider className="mt-2" />

      <InsightCard />

      <section className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
        <Reveal>
          <BentoShowcase />
        </Reveal>
      </section>

      <GlowDivider />

      <section className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
        <Reveal>
          <h2 className="font-serif-display text-gradient mb-6 text-3xl md:text-4xl">
            Featured Stories
          </h2>
          <FeaturedSlider items={featured} />
        </Reveal>
      </section>

      <GlowDivider />

      <YouTubeShowcaseSection />

      {/* Ad space after the hero */}
      <div className="mx-auto max-w-6xl px-4 pt-2 sm:px-6">
        <AdSlot format="leaderboard" />
      </div>

      <section className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
        <Reveal className="flex flex-wrap items-end justify-between gap-4">
          <h2 className="font-serif-display text-gradient text-3xl md:text-4xl">
            Latest Tech Articles
          </h2>

          <Link
            to="/blog"
            className="text-sm font-semibold text-accent-vivid transition-opacity hover:opacity-80"
          >
            View all
          </Link>
        </Reveal>

        <Reveal delay={80} className="mt-6">
          <CategoryTabs categories={categories} active={category} onChange={setCategory} />
        </Reveal>

        <div
          key={category}
          className="mt-8 grid gap-6 motion-safe:animate-[fade-in_0.4s_ease-out_both] sm:grid-cols-2 lg:grid-cols-3"
        >
          {filtered.map((a, i) => (
            <Reveal key={a.slug} delay={(i % 3) * 90} className="h-full">
              <ArticleCard article={a} />
            </Reveal>
          ))}
        </div>
      </section>

      <GlowDivider />

      <section className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
        <Reveal>
          <Newsletter />
        </Reveal>
      </section>

      <GlowDivider />

      <section className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
        <Reveal>
          <FaqSection />
        </Reveal>
      </section>

      <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
        <AdSlot format="leaderboard" />
      </div>
    </>
  );
}
