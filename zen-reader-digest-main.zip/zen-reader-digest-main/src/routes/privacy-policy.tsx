import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/privacy-policy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — How UPISTEPS Handles Data" },
      {
        name: "description",
        content:
          "How UPISTEPS collects, uses and protects visitor data, including analytics and third-party advertising cookies.",
      },
      { property: "og:title", content: "Privacy Policy — UPISTEPS" },
      {
        property: "og:description",
        content: "How UPISTEPS collects, uses and protects visitor data.",
      },
    ],
  }),
  component: Privacy,
});

function Privacy() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-14 sm:px-6">
      <h1 className="text-3xl font-bold tracking-tight md:text-4xl">Privacy Policy</h1>
      <p className="mt-3 text-sm text-muted-foreground">Last updated: 1 August 2026</p>

      <h2 className="mt-10 text-2xl font-semibold tracking-tight">Information we collect</h2>
      <p className="mt-4 leading-8 text-muted-foreground">
        We collect only what is needed to run the site: aggregated page analytics, and any details
        you voluntarily submit through the contact form.
      </p>

      <h2 className="mt-10 text-2xl font-semibold tracking-tight">Cookies and advertising</h2>
      <p className="mt-4 leading-8 text-muted-foreground">
        This site may display advertising served by third-party networks. Those networks may use
        cookies or similar technologies to serve ads based on your prior visits to this and other
        websites. You can opt out of personalised advertising through your browser or your ad
        settings with the relevant provider.
      </p>

      <h2 className="mt-10 text-2xl font-semibold tracking-tight">How we use your information</h2>
      <p className="mt-4 leading-8 text-muted-foreground">
        To respond to enquiries, to understand which articles are useful, and to keep the site
        secure. We do not sell personal information.
      </p>

      <h2 className="mt-10 text-2xl font-semibold tracking-tight">Your rights</h2>
      <p className="mt-4 leading-8 text-muted-foreground">
        You may request access to, correction of, or deletion of any personal data we hold about
        you. Contact us and we will respond within thirty days.
      </p>
    </div>
  );
}
