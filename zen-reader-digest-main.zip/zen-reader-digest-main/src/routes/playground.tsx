import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Reveal } from "@/components/site/Reveal";
import { GlowDivider } from "@/components/site/GlowDivider";

export const Route = createFileRoute("/playground")({
  head: () => ({
    meta: [
      { title: "Playground — Interactive Tech Tools & Trivia | UPISTEPS" },
      {
        name: "description",
        content:
          "Free interactive utilities from UPISTEPS: byte converter, password strength checker, text stats, plus a quick tech trivia quiz.",
      },
      { property: "og:title", content: "UPISTEPS Playground — Tech Tools & Trivia" },
      {
        property: "og:description",
        content: "Interactive developer utilities and a fast tech trivia quiz.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PlaygroundPage,
});

const trivia = [
  {
    q: "What does the 'HTTP' status code 418 famously mean?",
    options: ["I'm a teapot", "Rate limited", "Gateway timeout", "Payment required"],
    answer: 0,
  },
  {
    q: "Which data structure powers a browser's back button?",
    options: ["Queue", "Stack", "Heap", "Trie"],
    answer: 1,
  },
  {
    q: "What does 'GPU' stand for?",
    options: [
      "General Processing Unit",
      "Graphics Processing Unit",
      "Grid Power Unit",
      "Graphical Pipeline Utility",
    ],
    answer: 1,
  },
];

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-3xl border border-border bg-background/60 p-6 backdrop-blur-xl transition-all duration-300 hover:-translate-y-0.5 hover:border-[color-mix(in_oklab,var(--accent-vivid)_45%,transparent)] hover:shadow-[var(--shadow-glow)]">
      <h2 className="text-lg font-semibold tracking-tight">{title}</h2>
      <div className="mt-4">{children}</div>
    </section>
  );
}

function ByteConverter() {
  const [bytes, setBytes] = useState("1048576");
  const n = Number(bytes) || 0;
  const units = ["B", "KB", "MB", "GB", "TB"];
  let v = n;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return (
    <div className="space-y-3">
      <input
        type="number"
        value={bytes}
        onChange={(e) => setBytes(e.target.value)}
        className="h-11 w-full rounded-full border border-input bg-secondary/60 px-4 text-sm outline-none focus:border-[color-mix(in_oklab,var(--accent-vivid)_60%,transparent)] focus:ring-2 focus:ring-ring/25"
        aria-label="Bytes"
      />
      <p className="text-sm text-muted-foreground">
        = <span className="font-semibold text-accent-vivid">{v.toFixed(2)} {units[i]}</span>
      </p>
      <button
        type="button"
        onClick={() => {
          navigator.clipboard?.writeText(`${v.toFixed(2)} ${units[i]}`);
          toast.success("Copied to clipboard");
        }}
        className="btn-premium inline-flex h-10 items-center rounded-full px-5 text-sm font-semibold"
      >
        Copy result
      </button>
    </div>
  );
}

function PasswordStrength() {
  const [pw, setPw] = useState("");
  const score = useMemo(() => {
    let s = 0;
    if (pw.length >= 8) s++;
    if (pw.length >= 14) s++;
    if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) s++;
    if (/\d/.test(pw)) s++;
    if (/[^A-Za-z0-9]/.test(pw)) s++;
    return s;
  }, [pw]);
  const labels = ["Very weak", "Weak", "Fair", "Good", "Strong", "Elite"];
  return (
    <div className="space-y-3">
      <input
        type="text"
        value={pw}
        onChange={(e) => setPw(e.target.value)}
        placeholder="Type a sample passphrase…"
        className="h-11 w-full rounded-full border border-input bg-secondary/60 px-4 text-sm outline-none focus:border-[color-mix(in_oklab,var(--accent-vivid)_60%,transparent)] focus:ring-2 focus:ring-ring/25"
        aria-label="Sample password"
      />
      <div className="h-2 w-full overflow-hidden rounded-full bg-secondary">
        <div
          className="h-full bg-[image:var(--gradient-accent)] transition-all duration-500"
          style={{ width: `${(score / 5) * 100}%` }}
        />
      </div>
      <p className="text-sm text-muted-foreground">
        Strength: <span className="font-semibold text-accent-vivid">{labels[score]}</span>
      </p>
    </div>
  );
}

function TextStats() {
  const [text, setText] = useState("");
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  return (
    <div className="space-y-3">
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={4}
        placeholder="Paste a draft to measure…"
        className="w-full rounded-2xl border border-input bg-secondary/60 p-4 text-sm outline-none focus:border-[color-mix(in_oklab,var(--accent-vivid)_60%,transparent)] focus:ring-2 focus:ring-ring/25"
        aria-label="Text to analyse"
      />
      <p className="text-sm text-muted-foreground">
        {words} words · {text.length} characters ·{" "}
        <span className="font-semibold text-accent-vivid">
          {Math.max(1, Math.ceil(words / 220))} min read
        </span>
      </p>
    </div>
  );
}

function Trivia() {
  const [picked, setPicked] = useState<Record<number, number>>({});
  return (
    <div className="space-y-6">
      {trivia.map((t, qi) => (
        <div key={t.q}>
          <p className="text-sm font-semibold">{t.q}</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {t.options.map((o, oi) => {
              const chosen = picked[qi] === oi;
              const correct = oi === t.answer;
              return (
                <button
                  key={o}
                  type="button"
                  onClick={() => {
                    setPicked((p) => ({ ...p, [qi]: oi }));
                    if (correct) toast.success("Correct!", { description: o });
                    else
                      toast.error("Not quite", {
                        description: `The answer is “${t.options[t.answer]}”.`,
                      });
                  }}
                  className={`rounded-full border px-4 py-2 text-xs font-semibold transition-all duration-300 hover:-translate-y-0.5 sm:text-sm ${
                    chosen && correct
                      ? "border-transparent bg-[image:var(--gradient-accent)] text-primary-foreground shadow-[var(--shadow-glow)]"
                      : chosen
                        ? "border-destructive/60 text-destructive"
                        : "border-border bg-background/60 text-muted-foreground hover:text-accent-vivid"
                  }`}
                >
                  {o}
                </button>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

function PlaygroundPage() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
      <Reveal>
        <header className="text-center">
          <span className="inline-flex rounded-full border border-[color-mix(in_oklab,var(--accent-vivid)_40%,transparent)] px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.2em] text-accent-vivid">
            Playground
          </span>
          <h1 className="text-gradient mx-auto mt-5 max-w-3xl text-4xl md:text-5xl">
            Interactive tools & tech trivia
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
            Small, fast utilities we actually use in the newsroom — plus a quick quiz to test your
            tech instincts.
          </p>
        </header>
      </Reveal>

      <GlowDivider />

      <div className="grid gap-6 md:grid-cols-3">
        <Reveal>
          <Card title="Byte converter">
            <ByteConverter />
          </Card>
        </Reveal>
        <Reveal delay={80}>
          <Card title="Password strength">
            <PasswordStrength />
          </Card>
        </Reveal>
        <Reveal delay={160}>
          <Card title="Reading time & text stats">
            <TextStats />
          </Card>
        </Reveal>
      </div>

      <GlowDivider />

      <Reveal>
        <Card title="Tech trivia">
          <Trivia />
        </Card>
      </Reveal>
    </div>
  );
}
