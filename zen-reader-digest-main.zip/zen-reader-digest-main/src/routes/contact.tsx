import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { AdSlot } from "@/components/site/AdSlot";

const CONTACT_EMAIL = "support@upisteps.in";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact Us — Pitches, Corrections & Advertising" },
      {
        name: "description",
        content:
          "Get in touch with the UPISTEPS editorial team about story pitches, corrections, or advertising enquiries.",
      },
      { property: "og:title", content: "Contact Us — UPISTEPS" },
      {
        property: "og:description",
        content: "Reach the UPISTEPS team about pitches, corrections or advertising.",
      },
    ],
  }),
  component: Contact,
});

function Contact() {
  const [sent, setSent] = useState(false);

  function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new FormData(form);
    const name = String(data.get("name") ?? "").trim();
    const email = String(data.get("email") ?? "").trim();
    const message = String(data.get("message") ?? "").trim();
    if (!name || !email || !message) {
      toast.error("Please fill in all fields");
      return;
    }
    const subject = encodeURIComponent(`UPISTEPS contact: ${name}`);
    const body = encodeURIComponent(
      `Name: ${name}\nEmail: ${email}\n\nMessage:\n${message}`
    );
    window.location.href = `mailto:${CONTACT_EMAIL}?subject=${subject}&body=${body}`;
    setSent(true);
    form.reset();
    toast.success("Opening your mail app…", {
      description: `Your message is addressed to ${CONTACT_EMAIL}.`,
    });
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-14 sm:px-6">
      <h1 className="text-3xl font-bold tracking-tight md:text-4xl">Contact Us</h1>
      <p className="mt-4 max-w-xl leading-8 text-muted-foreground">
        Story pitches, corrections and advertising enquiries are all welcome. We reply to most
        messages within two business days.
      </p>

      <form onSubmit={onSubmit} className="mt-10 grid gap-5">
        <div className="grid gap-2">
          <label htmlFor="name" className="text-sm font-medium">
            Name
          </label>
          <input
            id="name"
            name="name"
            required
            className="h-11 rounded-md border border-input bg-background px-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-ring/30"
          />
        </div>
        <div className="grid gap-2">
          <label htmlFor="email" className="text-sm font-medium">
            Email
          </label>
          <input
            id="email"
            name="email"
            type="email"
            required
            className="h-11 rounded-md border border-input bg-background px-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-ring/30"
          />
        </div>
        <div className="grid gap-2">
          <label htmlFor="message" className="text-sm font-medium">
            Message
          </label>
          <textarea
            id="message"
            name="message"
            rows={6}
            required
            className="rounded-md border border-input bg-background p-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-ring/30"
          />
        </div>
        <div>
          <button
            type="submit"
            className="inline-flex h-11 items-center rounded-md bg-primary px-6 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Send message
          </button>
        </div>
        {sent && (
          <p className="text-sm font-medium text-primary" role="status">
            Your mail app should now be open with your message addressed to {CONTACT_EMAIL} —
            just press send.
          </p>
        )}
        <p className="text-sm text-muted-foreground">
          Prefer email directly? Write to us at{" "}
          <a href={`mailto:${CONTACT_EMAIL}`} className="font-medium text-primary underline">
            {CONTACT_EMAIL}
          </a>
          .
        </p>
      </form>

      <div className="mt-14">
        <AdSlot format="leaderboard" />
      </div>
    </div>
  );
}
