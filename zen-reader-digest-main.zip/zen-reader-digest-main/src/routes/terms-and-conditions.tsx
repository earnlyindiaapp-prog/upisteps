import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/terms-and-conditions")({
  head: () => ({
    meta: [
      { title: "Terms & Conditions — Using the UPISTEPS Website" },
      {
        name: "description",
        content:
          "The terms that govern your use of the UPISTEPS website, including content licensing, acceptable use and liability.",
      },
      { property: "og:title", content: "Terms & Conditions — UPISTEPS" },
      {
        property: "og:description",
        content: "The terms that govern your use of the UPISTEPS website.",
      },
    ],
  }),
  component: Terms,
});

function Terms() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-14 sm:px-6">
      <h1 className="text-3xl font-bold tracking-tight md:text-4xl">Terms &amp; Conditions</h1>
      <p className="mt-3 text-sm text-muted-foreground">Last updated: 1 August 2026</p>

      <h2 className="mt-10 text-2xl font-semibold tracking-tight">Acceptance of terms</h2>
      <p className="mt-4 leading-8 text-muted-foreground">
        By accessing this website you agree to these terms. If you do not agree, please stop using
        the site.
      </p>

      <h2 className="mt-10 text-2xl font-semibold tracking-tight">Use of content</h2>
      <p className="mt-4 leading-8 text-muted-foreground">
        Articles are provided for personal, non-commercial reading. You may quote short excerpts
        with clear attribution and a link to the original page. Republishing full articles requires
        written permission.
      </p>

      <h2 className="mt-10 text-2xl font-semibold tracking-tight">Accuracy and liability</h2>
      <p className="mt-4 leading-8 text-muted-foreground">
        Content is published in good faith and offered as general information, not professional
        advice. We are not liable for losses arising from decisions made on the basis of anything
        published here.
      </p>

      <h2 className="mt-10 text-2xl font-semibold tracking-tight">External links</h2>
      <p className="mt-4 leading-8 text-muted-foreground">
        We link to third-party sites we consider useful, but we do not control them and are not
        responsible for their content or practices.
      </p>

      <h2 className="mt-10 text-2xl font-semibold tracking-tight">Changes</h2>
      <p className="mt-4 leading-8 text-muted-foreground">
        These terms may be updated from time to time. Continued use of the site after changes are
        posted constitutes acceptance of the revised terms.
      </p>
    </div>
  );
}
