import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { CalendarClock, Clock } from "lucide-react";
import { articles, formatDate, getArticle } from "@/lib/articles";
import { AdSlot } from "@/components/site/AdSlot";
import { ArticleCard } from "@/components/site/ArticleCard";
import { Reveal } from "@/components/site/Reveal";

export const Route = createFileRoute("/blog/$slug")({
  loader: ({ params }) => {
    const article = getArticle(params.slug);
    if (!article) throw notFound();
    return { article };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [{ title: "Article not found | UPISTEPS" }, { name: "robots", content: "noindex" }],
      };
    }
    const { article } = loaderData;
    return {
      meta: [
        { title: `${article.title} | UPISTEPS` },
        { name: "description", content: article.excerpt },
        { property: "og:title", content: article.title },
        { property: "og:description", content: article.excerpt },
        { property: "og:type", content: "article" },
        { property: "og:image", content: article.image },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "twitter:image", content: article.image },
      ],
    };
  },
  notFoundComponent: ArticleNotFound,
  component: ArticlePage,
});

function ArticleNotFound() {
  return (
    <div className="mx-auto max-w-2xl px-4 py-24 text-center sm:px-6">
      <h1 className="text-2xl font-bold tracking-tight">Article not found</h1>
      <p className="mt-3 text-muted-foreground">
        This post may have been moved or renamed. Browse the blog for the latest articles.
      </p>
      <Link
        to="/blog"
        className="btn-premium mt-6 inline-flex h-11 items-center rounded-full px-6 text-sm font-semibold"
      >
        Back to blog
      </Link>
    </div>
  );
}

function ArticlePage() {
  const { article } = Route.useLoaderData();
  const related = articles.filter((a) => a.slug !== article.slug).slice(0, 3);
  const midpoint = Math.ceil(article.sections.length / 2);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <div className="grid gap-12 lg:grid-cols-[minmax(0,1fr)_300px]">
        <article>
          <nav className="text-xs text-muted-foreground" aria-label="Breadcrumb">
            <Link to="/" className="hover:text-accent-vivid">
              Home
            </Link>
            <span className="px-1.5">/</span>
            <Link to="/blog" className="hover:text-accent-vivid">
              Blog
            </Link>
          </nav>

          <p className="mt-6 text-xs font-semibold uppercase tracking-[0.18em] text-accent-vivid">
            {article.category}
          </p>
          <h1 className="font-serif-display mt-3 text-4xl leading-[1.12] md:text-[3rem]">
            {article.title}
          </h1>
          <div className="mt-5 flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
            <span className="font-medium text-foreground">{article.author}</span>
            <span aria-hidden>·</span>
            <time dateTime={article.date}>{formatDate(article.date)}</time>
          </div>
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-[color-mix(in_oklab,var(--accent-vivid)_35%,transparent)] bg-[color-mix(in_oklab,var(--accent-vivid)_8%,transparent)] px-3 py-1.5 text-xs font-semibold text-accent-vivid">
              <Clock className="h-3.5 w-3.5" aria-hidden />
              {article.readingTime}
            </span>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-secondary px-3 py-1.5 text-xs font-semibold text-secondary-foreground">
              <CalendarClock className="h-3.5 w-3.5" aria-hidden />
              Last updated {formatDate(article.updated ?? article.date)}
            </span>
          </div>

          <img
            src={article.image}
            alt={article.title}
            width={1200}
            height={675}
            className="mt-8 aspect-[16/9] w-full rounded-2xl border border-border object-cover"
          />

          <p className="article-body mt-9 font-medium text-foreground">{article.intro}</p>

          {article.sections.map((section, i) => (
            <div key={section.heading ?? i}>
              {i === midpoint && (
                <div className="my-10">
                  <AdSlot format="rectangle" label="Featured" />
                </div>
              )}
              {section.heading && (
                <h2 className="font-serif-display mt-14 text-3xl">{section.heading}</h2>
              )}
              {section.sub && (
                <h3 className="font-serif-display mt-8 text-xl text-foreground">
                  {section.sub}
                </h3>
              )}
              {section.body.map((p, j) => (
                <p key={j} className="article-body mt-6">
                  {p}
                </p>
              ))}
              {section.bullets && (
                <ul className="article-body mt-6 space-y-3">
                  {section.bullets.map((b) => (
                    <li key={b} className="flex gap-3">
                      <span
                        aria-hidden
                        className="mt-[0.7em] h-1.5 w-1.5 shrink-0 rounded-full bg-accent-vivid"
                      />
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>
              )}
              {section.image && (
                <figure className="mt-8">
                  <img
                    src={section.image}
                    alt={section.imageAlt ?? section.heading ?? article.title}
                    width={1200}
                    height={675}
                    loading="lazy"
                    className="aspect-[16/9] w-full rounded-2xl border border-border object-cover"
                  />
                  {section.imageCaption && (
                    <figcaption className="mt-3 text-center text-xs text-muted-foreground">
                      {section.imageCaption}
                    </figcaption>
                  )}
                </figure>
              )}
            </div>
          ))}

          <div className="mt-12 flex flex-wrap gap-2 border-t border-border pt-8">
            {article.tags.map((tag) => (
              <span
                key={tag}
                className="rounded-full bg-secondary px-3 py-1 text-xs font-medium text-secondary-foreground"
              >
                #{tag}
              </span>
            ))}
          </div>

          <div className="mt-10">
            <AdSlot format="leaderboard" />
          </div>
        </article>

        <aside className="space-y-8 lg:sticky lg:top-24 lg:self-start">
          <div className="rounded-xl border border-border p-5">
            <h2 className="text-sm font-semibold tracking-tight">More from UPISTEPS</h2>
            <ul className="mt-4 space-y-4">
              {related.map((a) => (
                <li key={a.slug}>
                  <Link
                    to="/blog/$slug"
                    params={{ slug: a.slug }}
                    className="text-sm font-medium leading-snug transition-colors hover:text-accent-vivid"
                  >
                    {a.title}
                  </Link>
                  <p className="mt-1 text-xs text-muted-foreground">{formatDate(a.date)}</p>
                </li>
              ))}
            </ul>
          </div>
          {/* Sidebar ad space */}
          <AdSlot format="tower" />
        </aside>
      </div>

      <section className="mt-20">
        <h2 className="text-2xl font-bold tracking-tight">Related reading</h2>
        <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {related.map((a, i) => (
            <Reveal key={a.slug} delay={(i % 3) * 90} className="h-full">
              <ArticleCard article={a} />
            </Reveal>
          ))}
        </div>
      </section>
    </div>
  );
}
