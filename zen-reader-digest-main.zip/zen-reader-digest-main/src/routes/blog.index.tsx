import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Search, Tag as TagIcon, X } from "lucide-react";
import { useState, type FormEvent } from "react";
import { allTags, categories, filterArticles } from "@/lib/articles";
import { ArticleCard } from "@/components/site/ArticleCard";
import { AdSlot } from "@/components/site/AdSlot";
import { Reveal } from "@/components/site/Reveal";

type BlogSearch = {
  q?: string | undefined;
  category?: string | undefined;
  tag?: string | undefined;
};

export const Route = createFileRoute("/blog/")({
  validateSearch: (search: Record<string, unknown>): BlogSearch => ({
    q: typeof search["q"] === "string" ? search["q"] : undefined,
    category: typeof search["category"] === "string" ? search["category"] : undefined,
    tag: typeof search["tag"] === "string" ? search["tag"] : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Blog — All Articles | UPISTEPS" },
      {
        name: "description",
        content:
          "Browse and search every UPISTEPS article by category or tag — fintech, AI, web development, cloud, hardware and security.",
      },
      { property: "og:title", content: "Blog — All Articles | UPISTEPS" },
      {
        property: "og:description",
        content: "Browse and search every UPISTEPS article by category or tag.",
      },
    ],
  }),
  component: BlogIndex,
});

function BlogIndex() {
  const { q = "", category, tag } = Route.useSearch();
  const navigate = useNavigate();
  const [value, setValue] = useState(q);
  const results = filterArticles({ q, category, tag });

  function update(patch: Partial<BlogSearch>) {
    navigate({
      to: "/blog",
      search: (prev: BlogSearch) => ({ ...prev, ...patch }),
    });
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    update({ q: value.trim() || undefined });
  }

  const chip = (active: boolean) =>
    `rounded-full border px-4 py-1.5 text-sm font-medium transition-all ${
      active
        ? "border-primary bg-primary text-primary-foreground shadow-[0_0_18px_-4px] shadow-primary/60"
        : "border-border bg-background/60 text-muted-foreground hover:border-primary/50 hover:text-foreground"
    }`;

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
      <h1 className="font-serif-display text-4xl md:text-5xl">Blog</h1>
      <p className="mt-3 max-w-2xl text-muted-foreground">
        Every article we have published. Filter by category, tag, or keyword.
      </p>

      <form onSubmit={onSubmit} role="search" className="mt-6 max-w-md">
        <label htmlFor="blog-search" className="sr-only">
          Search articles
        </label>
        <div className="relative">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden
          />
          <input
            id="blog-search"
            type="search"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder="Search by keyword…"
            className="h-11 w-full rounded-md border border-input bg-background pl-9 pr-24 text-sm outline-none placeholder:text-muted-foreground focus:border-primary focus:ring-2 focus:ring-ring/30"
          />
          <button
            type="submit"
            className="absolute right-1.5 top-1/2 h-8 -translate-y-1/2 rounded-md bg-primary px-3 text-xs font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Search
          </button>
        </div>
      </form>

      {/* Category tabs */}
      <div className="mt-8 flex flex-wrap items-center gap-2" role="group" aria-label="Filter by category">
        <button type="button" onClick={() => update({ category: undefined })} className={chip(!category)}>
          All
        </button>
        {categories.map((c) => (
          <button
            key={c}
            type="button"
            onClick={() => update({ category: c === category ? undefined : c })}
            className={chip(category === c)}
            aria-pressed={category === c}
          >
            {c}
          </button>
        ))}
      </div>

      {/* Tag chips */}
      <div className="mt-4 flex flex-wrap items-center gap-2" role="group" aria-label="Filter by tag">
        <span className="inline-flex items-center gap-1 text-xs font-medium uppercase tracking-wide text-muted-foreground">
          <TagIcon className="h-3.5 w-3.5" aria-hidden /> Tags
        </span>
        {allTags.map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => update({ tag: t === tag ? undefined : t })}
            aria-pressed={tag === t}
            className={`rounded-full border px-3 py-1 text-xs transition-all ${
              tag === t
                ? "border-primary bg-primary/15 text-primary"
                : "border-border/70 text-muted-foreground hover:border-primary/40 hover:text-foreground"
            }`}
          >
            #{t}
          </button>
        ))}
      </div>

      {/* Active filters summary */}
      {(category || tag) && (
        <div className="mt-4 flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
          <span>Filtering by:</span>
          {category && (
            <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
              {category}
              <button type="button" onClick={() => update({ category: undefined })} aria-label={`Remove ${category} filter`}>
                <X className="h-3 w-3" />
              </button>
            </span>
          )}
          {tag && (
            <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
              #{tag}
              <button type="button" onClick={() => update({ tag: undefined })} aria-label={`Remove ${tag} filter`}>
                <X className="h-3 w-3" />
              </button>
            </span>
          )}
          <button
            type="button"
            onClick={() => navigate({ to: "/blog", search: {} })}
            className="text-xs font-medium text-primary underline-offset-2 hover:underline"
          >
            Clear all
          </button>
        </div>
      )}

      <div className="mt-8">
        <AdSlot format="leaderboard" />
      </div>

      <p className="mt-8 text-sm text-muted-foreground" aria-live="polite">
        {results.length} article{results.length === 1 ? "" : "s"}
        {q ? ` matching “${q}”` : ""}
        {category ? ` in ${category}` : ""}
        {tag ? ` tagged #${tag}` : ""}
      </p>

      {results.length > 0 ? (
        <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {results.map((a, i) => (
            <Reveal key={a.slug} delay={(i % 3) * 90} className="h-full">
              <ArticleCard article={a} />
            </Reveal>
          ))}
        </div>
      ) : (
        <div className="mt-6 rounded-xl border border-dashed border-border p-12 text-center">
          <h2 className="text-base font-semibold">No articles match these filters</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Try clearing a filter or using a broader keyword such as “security” or “ai”.
          </p>
        </div>
      )}
    </div>
  );
}
