import { createFileRoute } from "@tanstack/react-router";
import { AdSlot } from "@/components/site/AdSlot";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Us — Who Writes UPISTEPS" },
      {
        name: "description",
        content:
          "UPISTEPS is an independent technology publication covering AI, web performance, cloud and security with practical, hype-free reporting.",
      },
      { property: "og:title", content: "About Us — Who Writes UPISTEPS" },
      {
        property: "og:description",
        content: "An independent technology publication for people who ship software.",
      },
    ],
  }),
  component: About,
});

function About() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-14 sm:px-6">
      <h1 className="text-3xl font-bold tracking-tight md:text-4xl">About Us</h1>
      <p className="mt-6 text-lg leading-8 text-muted-foreground">
        UPISTEPS is an independent technology publication. We write for engineers, technical
        founders and the product people who work alongside them.
      </p>

      <h2 className="mt-12 text-2xl font-semibold tracking-tight">What we cover</h2>
      <p className="mt-4 leading-8 text-muted-foreground">
        Artificial intelligence in production, web performance, cloud economics, developer tooling
        and security. If a topic cannot be tied back to a decision someone has to make this quarter,
        we usually skip it.
      </p>

      <h2 className="mt-10 text-2xl font-semibold tracking-tight">How we work</h2>
      <h3 className="mt-6 text-lg font-semibold tracking-tight">Short and specific</h3>
      <p className="mt-3 leading-8 text-muted-foreground">
        Articles are edited down until only the useful parts remain. Most take five to seven minutes
        to read.
      </p>
      <h3 className="mt-6 text-lg font-semibold tracking-tight">Independent</h3>
      <p className="mt-3 leading-8 text-muted-foreground">
        We accept display advertising, clearly marked as such. Sponsors never see articles before
        publication and never influence coverage.
      </p>

      <div className="mt-14">
        <AdSlot format="leaderboard" />
      </div>
    </div>
  );
}
