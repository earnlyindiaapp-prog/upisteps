import type { Article } from "./articles";

const img = (id: string) =>
  `https://images.unsplash.com/${id}?auto=format&fit=crop&w=1600&q=80`;

/**
 * Long-form pillar articles. Kept in a separate module so the main
 * article registry stays readable; merged into `articles` in articles.ts.
 */
export const pillarArticles: Article[] = [
  {
    slug: "upi-autopay-mandates-explained",
    title: "UPI AutoPay and Recurring Mandates: The Money Leak Nobody Audits",
    excerpt:
      "Subscriptions, SIPs and utility mandates quietly stack up on a single UPI handle. Here is how mandates actually work, how to audit every one you have approved, and how to cancel cleanly.",
    category: "Fintech",
    date: "2026-08-26",
    updated: "2026-08-28",
    readingTime: "12 min read",
    author: "UPISTEPS Editorial",
    image: img("photo-1554224155-8d04cb21cd6c"),
    tags: ["upi", "autopay", "subscriptions", "fintech", "banking", "india"],
    intro:
      "Almost everyone with a smartphone has approved a recurring payment mandate in the last two years, and almost nobody can list the ones currently active against their account. A mandate is a standing instruction that lets a merchant pull money on a schedule without asking again. That is enormously convenient and, unaudited, it is the most reliable way to lose small amounts of money every month for years. This guide explains the mechanism, the exact places to review your approvals, and what genuinely stops a charge you no longer want.",
    sections: [
      {
        heading: "A mandate is permission, not a payment",
        body: [
          "When you tap approve on an AutoPay screen you are not sending money. You are registering an instruction with your bank that names a merchant, a maximum amount, a frequency, and an end date. Every later debit is the merchant presenting that instruction and the bank honouring it silently.",
          "The maximum amount matters more than the amount you saw on screen. A mandate approved for a two hundred rupee plan is often registered with a higher ceiling so the merchant can raise prices without re-asking. Read the cap, not the current price.",
          "The end date matters just as much. Many mandates default to a term of several years or to an open-ended validity. Convenience at signup becomes a very long tail.",
        ],
        image: img("photo-1563986768609-322da13575f3"),
        imageAlt: "Close-up of a payment card and phone on a desk",
        imageCaption:
          "Approving AutoPay registers a ceiling and a term, not just today's price.",
      },
      {
        heading: "Where the debits actually come from",
        sub: "Three different rails wearing the same badge",
        body: [
          "Recurring charges reach you through more than one system, and they are cancelled in different places. UPI AutoPay mandates live inside your UPI app. Card-on-file standing instructions live with your card issuer. Direct debit style mandates registered against your bank account live with the bank branch or net banking portal.",
          "This is why cancelling inside a merchant's app sometimes stops the service but not the debit, and sometimes stops the debit but not the service. You have to kill the permission at the rail that grants it.",
          "A practical rule: if the original approval screen showed your UPI PIN pad, it is a UPI mandate. If it showed a card CVV and an OTP, it is a card standing instruction.",
        ],
        bullets: [
          "UPI AutoPay: cancel inside the UPI app that created it",
          "Card standing instruction: cancel with the card issuer",
          "Bank mandate: cancel through net banking or the branch",
          "Merchant cancellation alone is not proof the mandate is dead",
        ],
      },
      {
        heading: "How to audit every mandate in fifteen minutes",
        body: [
          "Open each UPI app installed on your phone, not just the one you use most, because a mandate stays with the app that registered it even if you stopped using that app. Look for a section named AutoPay, Mandates, or Subscriptions inside the profile menu.",
          "List every active mandate with its merchant name, ceiling amount, frequency and next debit date. You will typically find one or two you do not recognise, usually a free trial that converted or a service you replaced but never cancelled.",
          "Then reconcile against your bank statement for the last ninety days. Filter for identical amounts recurring on similar dates. Anything on the statement that is not on your mandate list is either a card standing instruction or a manual charge, and both need separate follow-up.",
        ],
      },
      {
        heading: "Cancelling so it actually stops",
        body: [
          "Revoke the mandate at the rail first, then cancel the plan with the merchant. Doing it in that order prevents the merchant from re-presenting a charge during the notice period.",
          "Keep the confirmation. Every UPI app issues a mandate revocation reference. Screenshot it. If a debit still lands, that reference turns a long argument into a single complaint with your bank, which owns the dispute for anything debited from your account.",
          "For pre-debit notifications, do not ignore them. Regulation requires a notice before a recurring debit above a threshold. That notification is your last free chance to stop a charge without a dispute.",
        ],
        image: img("photo-1450101499163-c8848c66ca85"),
        imageAlt: "Notebook, pen and laptop used for reviewing statements",
        imageCaption:
          "Revoke at the rail, then cancel with the merchant, and keep the reference number.",
      },
      {
        heading: "Designing mandates if you are the merchant",
        sub: "Notes for builders",
        body: [
          "Set the mandate ceiling to a realistic multiple of the plan price rather than an arbitrary high number. Users who inspect it and find a ceiling twenty times their plan will churn, and rightly.",
          "Send the pre-debit notice with the amount, the date and a one-tap cancel path. Cancellation friction produces disputes, and disputes cost far more than the retained revenue.",
          "Handle mandate failures gracefully. A failed debit is usually a limit or balance issue, not intent to leave. Retry on a schedule, notify in plain language, and never suspend service on the first failure without a message.",
        ],
      },
      {
        heading: "The quarterly habit worth keeping",
        body: [
          "Put a recurring reminder on the first weekend of each quarter. Open your UPI apps, review the mandate list, and revoke anything you did not consciously use in the last three months.",
          "This single habit typically recovers more money per year than any cashback programme, and unlike cashback it compounds by removing charges rather than refunding a fraction of them.",
        ],
      },
    ],
  },
  {
    slug: "phone-battery-health-guide",
    title: "Phone Battery Health: What Actually Degrades It, With Evidence",
    excerpt:
      "Fast charging, overnight charging, heat and charge cycles — separating the engineering reality from repeated internet folklore, plus a routine that measurably extends battery life.",
    category: "Hardware",
    date: "2026-08-22",
    updated: "2026-08-27",
    readingTime: "11 min read",
    author: "Ravi Menon",
    image: img("photo-1585338447937-7082f8fc763d"),
    tags: ["hardware", "battery", "mobile", "charging", "maintenance"],
    intro:
      "Battery advice online is a mixture of decade-old laptop lore, marketing copy, and a small amount of genuine electrochemistry. The genuine part is worth knowing, because a lithium-ion cell degrades in ways you can influence with a few habits that cost nothing. This is a plain-language account of what wears a battery out, what does not, and a routine that keeps a phone useful for an extra year.",
    sections: [
      {
        heading: "What a charge cycle really counts",
        body: [
          "A cycle is one hundred percent of capacity used, not one plug-in. Charging from sixty to one hundred four times equals roughly one and a half cycles, not four. This is why people who top up frequently are not burning through cycles the way the folklore claims.",
          "Manufacturers rate cells for a number of cycles to eighty percent of original capacity, typically several hundred to around a thousand under lab conditions. Real-world results land lower because lab conditions mean moderate temperature and moderate charge rates.",
          "Capacity loss is not linear. It is fastest in the first few months, then flattens, then accelerates again once the cell is well below eighty percent.",
        ],
        image: img("photo-1609091839311-d5365f9ff1c5"),
        imageAlt: "Smartphone charging with a cable on a wooden surface",
        imageCaption:
          "One cycle means one full capacity's worth of energy, not one plug-in.",
      },
      {
        heading: "Heat is the variable that matters most",
        sub: "More than charging speed, more than cycle count",
        body: [
          "Elevated temperature accelerates the chemical side reactions that permanently consume lithium inventory inside the cell. Sustained operation above roughly thirty-five degrees is where measurable damage begins, and above forty-five it is rapid.",
          "The worst common scenario is a phone charging inside a car on a dashboard, or gaming while plugged in in a warm room. Both combine an internal heat source with charging current and no route for the heat to leave.",
          "Simple fixes work: remove thick cases while charging fast, never charge under a pillow or blanket, and stop charging in direct sunlight. None of these cost anything and all of them measurably reduce cell temperature.",
        ],
        bullets: [
          "Take the case off during fast charges",
          "Never charge in a hot car or in direct sun",
          "Avoid heavy gaming while plugged in",
          "Let a hot phone cool before topping up",
        ],
      },
      {
        heading: "State of charge, and why eighty percent helps",
        body: [
          "A lithium-ion cell held at a very high state of charge sits at higher internal voltage, and higher voltage accelerates electrolyte breakdown. Time spent near one hundred percent is therefore more damaging than time spent in the middle of the range.",
          "This is the real basis for the eighty percent charge limits now built into most phones. The feature is not marketing. Keeping the daily range roughly between twenty and eighty measurably slows capacity loss, at the cost of some usable runtime each day.",
          "Deep discharges are also unhelpful. Repeatedly running to zero and leaving the phone flat for days can push the cell below its safe floor, which is the one scenario that can render a battery unrecoverable rather than merely worn.",
        ],
      },
      {
        heading: "Overnight charging: the honest answer",
        body: [
          "Modern phones stop drawing charge current when full and then trickle only as needed, so the old warning about overcharging does not apply. What does apply is the hours spent sitting at a high state of charge.",
          "Optimised or adaptive charging solves this properly by holding at around eighty percent overnight and completing the charge shortly before your usual wake time. If your phone offers it, turn it on and stop thinking about it.",
          "If it does not, charging in the evening rather than overnight achieves most of the same benefit with no software help.",
        ],
        image: img("photo-1512941937669-90a1b58e7e9c"),
        imageAlt: "Phone resting on a bedside table at night",
        imageCaption:
          "Adaptive charging removes most of the overnight penalty automatically.",
      },
      {
        heading: "Myths worth retiring",
        sub: "Repeated often, supported by nothing",
        body: [
          "Calibrating a battery by fully draining it monthly does nothing for the cell. It can recalibrate the percentage estimate the software shows, which is a display fix, not a health fix.",
          "Third-party chargers are not inherently harmful. Chargers that skip safety certification are, because they may deliver unregulated voltage. A certified charger from a reputable brand negotiates the same power profile as the original.",
          "Closing background apps does not extend battery life in any meaningful way on modern operating systems, and repeatedly relaunching apps costs more energy than leaving them suspended.",
        ],
      },
      {
        heading: "A routine that works",
        body: [
          "Enable the charge limit or adaptive charging feature. Keep the phone out of heat, especially while charging. Top up opportunistically instead of running to empty, and do not worry about partial charges.",
          "Check battery health in settings twice a year. When maximum capacity falls below roughly eighty percent, a replacement cell restores full performance for a fraction of a new device's cost, and it is by far the cheapest upgrade available to you.",
        ],
      },
    ],
  },
  {
    slug: "password-manager-and-passkeys-guide",
    title: "Password Managers and Passkeys: A Complete Setup Guide",
    excerpt:
      "Why reused passwords are still the leading cause of account takeover, how passkeys change the model, and a step-by-step migration that takes one evening.",
    category: "Security",
    date: "2026-08-20",
    updated: "2026-08-27",
    readingTime: "13 min read",
    author: "Maya Iyer",
    image: img("photo-1555949963-aa79dcee981c"),
    tags: ["security", "passwords", "passkeys", "privacy", "2fa"],
    intro:
      "The overwhelming majority of account compromises do not involve breaking encryption. They involve a password that was already stolen from a different site being tried against yours. Everything in this guide follows from that single fact. A password manager makes reuse unnecessary; passkeys make the stolen-password attack impossible for the accounts that support them. Setting both up properly is an evening of work that removes the largest category of personal security risk.",
    sections: [
      {
        heading: "The problem is reuse, not complexity",
        body: [
          "Requiring a symbol and a capital letter never stopped a breach. Attackers do not guess your password character by character; they take a list of billions of email and password pairs from previous leaks and replay it. If the pair works anywhere, that account is gone.",
          "This means the only property that protects you is uniqueness. A long, boring, unique password per site is strictly better than a clever, complex one used in three places.",
          "Humans cannot generate or remember dozens of unique strings. That is not a discipline failure, it is a design failure, and a manager is the fix.",
        ],
        image: img("photo-1614064641938-3bbee52942c7"),
        imageAlt: "A padlock resting on a laptop keyboard",
        imageCaption:
          "Uniqueness beats complexity. Reuse is what turns one breach into five.",
      },
      {
        heading: "Choosing a manager without overthinking it",
        sub: "The differences that actually matter",
        body: [
          "Any reputable manager with end-to-end encryption, a published security model and independent audits is a large improvement on your current situation. Do not stall for weeks comparing feature grids.",
          "The features that genuinely matter: cross-device sync you will actually use, a browser extension for autofill, secure sharing if you have a household or team, and an emergency access or recovery path.",
          "Autofill is a security feature, not a convenience feature. A manager refuses to fill credentials on a lookalike domain, which means it catches phishing pages that your eyes will not.",
        ],
        bullets: [
          "End-to-end encryption with a published model",
          "Independent third-party audits",
          "Reliable sync across every device you own",
          "A recovery path you have actually tested",
        ],
      },
      {
        heading: "The master password and recovery",
        body: [
          "Your master password is the one secret you still memorise. Make it a passphrase of four to six unrelated words. Length beats character soup, and a phrase is far easier to recall under stress.",
          "Write it once on paper and store it somewhere physically secure. This is not bad practice; the threat model for a piece of paper in a locked drawer is completely different from the threat model for a reused string on the internet.",
          "Set up and then actually test the recovery path. Most people discover their recovery kit does not work at the exact moment they need it. Test it while you still have access.",
        ],
      },
      {
        heading: "What a passkey is, in plain terms",
        body: [
          "A passkey is a key pair. The private half never leaves your device and is unlocked by your fingerprint, face or device PIN. The public half sits with the website. Signing in means your device proves it holds the private key.",
          "Nothing reusable is transmitted. There is no shared secret in a database for an attacker to steal, so a breach of the site yields nothing that logs anyone in. Phishing also fails, because the key is bound to the real domain and simply will not respond to a lookalike.",
          "Passkeys sync through your platform account or your password manager, so losing one device does not lock you out. Register a second device or a hardware key anyway.",
        ],
        image: img("photo-1601050690597-df0568f70950"),
        imageAlt: "A fingerprint sensor being used for authentication",
        imageCaption:
          "The private key never leaves the device, which is why phishing cannot capture it.",
      },
      {
        heading: "A migration plan for one evening",
        sub: "Highest impact first",
        body: [
          "Start with your primary email. It is the recovery address for everything else, so it is the account that unlocks all the others. Give it a unique generated password, then add a passkey or an authenticator app.",
          "Then do banking and payments, then anything with a saved card, then social accounts, then the long tail. Import your browser-saved passwords into the manager, run its breach and reuse report, and work down the list it produces.",
          "Switch two-factor from SMS to an authenticator app or passkey wherever it is offered. SMS codes are interceptable through SIM swap and are the weakest of the second factors still in common use.",
        ],
        bullets: [
          "Email first, then payments, then everything else",
          "Replace SMS codes with an app or passkey",
          "Run the reuse report and fix every flagged entry",
          "Register a backup device before you need it",
        ],
      },
      {
        heading: "Living with it afterwards",
        body: [
          "Let the manager generate every new password and never memorise one again. If a site offers a passkey, take it and remove the password afterwards where the site allows.",
          "Review the breach report quarterly. It is the closest thing to a health check for your online identity, and it takes about five minutes.",
        ],
      },
    ],
  },
  {
    slug: "wifi-router-setup-and-speed-guide",
    title: "Home Wi-Fi That Actually Works: Placement, Channels and Real Fixes",
    excerpt:
      "Why your speed test looks fine while video calls stutter, how to read the difference between plan speed and Wi-Fi speed, and the changes that genuinely fix dead zones.",
    category: "Hardware",
    date: "2026-08-18",
    updated: "2026-08-26",
    readingTime: "12 min read",
    author: "Ravi Menon",
    image: img("photo-1544197150-b99a580bb7a8"),
    tags: ["wifi", "networking", "router", "hardware", "home office"],
    intro:
      "Most home internet complaints are not internet complaints. The line into the building is usually delivering what was sold; the last ten metres of wireless between the router and the laptop is where the experience falls apart. Fixing that rarely requires a faster plan. It requires understanding three things: where radio waves actually go, which band you are connected to, and what a stutter on a call is really measuring.",
    sections: [
      {
        heading: "Plan speed and Wi-Fi speed are different numbers",
        body: [
          "The figure on your bill describes the connection arriving at the router. The figure your laptop sees describes a radio link that is shared with every other device in the home and degraded by every wall in between.",
          "Run a speed test twice: once on a device connected by cable to the router, and once on the device that feels slow. If the cabled test matches your plan and the wireless one does not, no provider call will help. The problem is inside your home.",
          "This single test saves most people a wasted support call and, more often, an unnecessary plan upgrade.",
        ],
        image: img("photo-1606904825846-647eb07f5be2"),
        imageAlt: "A home router with indicator lights on a shelf",
        imageCaption:
          "Test cabled and wireless separately before blaming the provider.",
      },
      {
        heading: "Placement beats hardware",
        sub: "Physics you cannot buy your way around",
        body: [
          "A router radiates roughly outward and slightly downward from its antennas. Put it on the floor, in a cupboard, behind a television or next to a metal cabinet, and you have discarded most of that coverage before it starts.",
          "Central and high is the rule. A shelf near the middle of the home, clear of large metal objects, aquariums and thick masonry, outperforms an expensive router shoved into a corner utility box.",
          "Water absorbs the frequencies Wi-Fi uses, which is why a wall with plumbing in it is far worse than a plasterboard partition, and why a room full of people performs worse than an empty one.",
        ],
        bullets: [
          "Central location, elevated, out in the open",
          "Away from metal, mirrors, and water tanks",
          "Antennas vertical for single-floor coverage",
          "Never inside a cupboard or media cabinet",
        ],
      },
      {
        heading: "Bands: range versus speed",
        body: [
          "The 2.4 GHz band travels furthest and penetrates walls best, but it is crowded and slow. The 5 GHz band is much faster and much less congested, but loses strength quickly through solid walls. Where available, 6 GHz is faster still with even shorter reach.",
          "Devices choose badly. A phone that latched onto 2.4 GHz in the far bedroom will often keep that connection when you walk back into the same room as the router, delivering a fraction of the available speed.",
          "If your router lets you, give the bands separate names during troubleshooting so you can see and control what a device is using. Merge them again once things are stable.",
        ],
      },
      {
        heading: "Stutter is latency and loss, not bandwidth",
        body: [
          "A video call needs only a few megabits. When it breaks up on a hundred megabit line, the problem is jitter and packet loss, not throughput. A raw speed test will look perfectly healthy while the call is unusable.",
          "The usual culprits are channel congestion from neighbouring networks, a weak signal causing retransmissions, or a device saturating the upload while someone else is on a call. Upload saturation is the most commonly missed one, because backups and cloud photo sync run silently.",
          "Enable the router's quality of service or smart queue feature if it has one. Prioritising interactive traffic over bulk transfers fixes more real complaints than any speed increase.",
        ],
        image: img("photo-1587440871875-191322ee64b0"),
        imageAlt: "Network cables plugged into a switch",
        imageCaption:
          "Calls break on jitter and loss, which a bandwidth test will not show.",
      },
      {
        heading: "Mesh, extenders and cable",
        sub: "Choosing the right escalation",
        body: [
          "A cheap repeater halves throughput because it receives and retransmits on the same radio. It can turn one weak zone into a wider mediocre zone, which sometimes helps and often does not.",
          "A mesh system with a dedicated backhaul radio, or better, with a network cable between nodes, does not suffer that penalty. If you can run a single cable to a second access point, that beats any wireless mesh at any price.",
          "For a desk that matters — a work machine, a console, a media box — a cable remains undefeated. Wireless is for mobility, not for equipment that never moves.",
        ],
      },
      {
        heading: "A twenty-minute tune-up",
        body: [
          "Move the router central and high. Update its firmware. Split or verify the bands and reconnect your main devices to the faster one. Change the Wi-Fi channel if a scan shows heavy overlap with neighbours. Enable quality of service. Cable anything stationary.",
          "Re-run both speed tests and, more importantly, make a real video call from the room that used to fail. That is the only benchmark that matches how you actually use the connection.",
        ],
      },
    ],
  },
  {
    slug: "cloud-storage-backup-strategy",
    title: "Cloud Storage and Backups: The 3-2-1 Rule for Normal People",
    excerpt:
      "Sync is not backup. A practical, low-cost system that survives a lost phone, a failed drive, ransomware and an accidental delete you notice six months later.",
    category: "Cloud",
    date: "2026-08-15",
    updated: "2026-08-26",
    readingTime: "11 min read",
    author: "Elena Ford",
    image: img("photo-1544383835-bda2bc66a55d"),
    tags: ["cloud", "backup", "storage", "data", "ransomware"],
    intro:
      "Everyone believes they have backups until the day they need one. Usually what they have is sync, which faithfully replicates a deletion or an encryption event to every device within seconds. The distinction is the whole subject. This is a practical backup design that ordinary households and small teams can actually maintain, built on a rule that has survived every change in storage technology for thirty years.",
    sections: [
      {
        heading: "Sync is not backup",
        body: [
          "A sync service exists to make every copy identical. If a file is deleted, corrupted or encrypted on one device, that state is the truth and it propagates. Identical copies are not independent copies.",
          "A backup exists to preserve a previous state. It must be able to answer the question: what did this folder look like last Tuesday? If your system cannot answer that, it is not a backup regardless of how much cloud storage you pay for.",
          "Most sync services do keep version history and a trash for a limited window, which helps. Windows are typically thirty days, which is shorter than the time it usually takes to notice a quiet corruption.",
        ],
        image: img("photo-1451187580459-43490279c0fa"),
        imageAlt: "Abstract representation of distributed cloud infrastructure",
        imageCaption:
          "Identical copies are not independent copies. Versions are what save you.",
      },
      {
        heading: "The 3-2-1 rule, restated",
        sub: "Three copies, two media, one offsite",
        body: [
          "Keep three copies of anything you cannot recreate. Store them on at least two different kinds of media or services, so a single product failure cannot take all of them. Keep at least one copy physically elsewhere, so a fire, flood or theft is survivable.",
          "The modern addition is a fourth condition: one copy should be offline or immutable, meaning ransomware running on your machine cannot reach and rewrite it. A cloud bucket with versioning and delete protection satisfies this, as does an external drive that is unplugged between backups.",
          "For most households this looks like: the working copy on your device, a cloud service with version history, and an external drive updated monthly and kept at a relative's house or in a drawer at work.",
        ],
        bullets: [
          "Three copies of irreplaceable data",
          "Two different storage types or providers",
          "One copy stored somewhere else physically",
          "One copy offline or write-protected",
        ],
      },
      {
        heading: "What is actually irreplaceable",
        body: [
          "Be honest about scope. Installed applications, downloaded media and operating system files are all re-obtainable and do not need backing up. Photos, documents you wrote, financial records, project files, key exports and years of messages are not.",
          "Write the list once. It is usually smaller than people expect, often under a few hundred gigabytes, which makes a proper backup far cheaper than the vague sense of a giant task suggests.",
          "Include the things that live only inside apps: authenticator seeds, password manager exports, note apps, and phone messages. These are the items people discover missing after a restore.",
        ],
      },
      {
        heading: "Ransomware changes the design",
        body: [
          "Ransomware encrypts everything it can write to, including mapped network drives and mounted cloud folders. A backup that is permanently mounted is a backup that gets encrypted alongside the original.",
          "Versioning saves you here, provided the retention window is long enough and the attacker cannot delete versions. Choose services that support object versioning and a delete hold, and set retention to at least ninety days.",
          "An unplugged external drive is crude and extremely effective. Software cannot encrypt a disk that is not connected.",
        ],
        image: img("photo-1510511459019-5dda7724fd87"),
        imageAlt: "Dark server room with rows of equipment",
        imageCaption:
          "Anything permanently mounted is within reach of anything running on your machine.",
      },
      {
        heading: "Test the restore, not the backup",
        sub: "The step everyone skips",
        body: [
          "A backup job reporting success proves data was written. It does not prove data can be read back, that the archive is not corrupt, or that you remember the encryption passphrase.",
          "Twice a year, restore a handful of real files to a new location and open them. Once a year, do a larger restore. Note how long it takes; recovery time is part of the plan, and discovering that a full restore takes four days is better learned in advance.",
          "Store recovery credentials outside the system being backed up. A password to your backup service that lives only in a file on the failed machine is not a password you have.",
        ],
      },
      {
        heading: "A setup you will maintain",
        body: [
          "Automate the cloud layer so it needs no attention. Keep the offline layer manual but scheduled, tied to a calendar reminder on a fixed date each month so it does not depend on remembering.",
          "The best backup system is the boring one that has been running unchanged for two years. Complexity is the enemy of maintenance, and an unmaintained backup is indistinguishable from no backup at the moment it matters.",
        ],
      },
    ],
  },
  {
    slug: "ai-chatbots-practical-daily-use",
    title: "Using AI Assistants Well: Prompts, Limits and Verification",
    excerpt:
      "A grounded guide to getting reliable output from AI assistants, understanding where they fail, and building a verification habit that keeps you out of trouble.",
    category: "Artificial Intelligence",
    date: "2026-08-12",
    updated: "2026-08-25",
    readingTime: "12 min read",
    author: "UPISTEPS Editorial",
    image: img("photo-1620712943543-bcc4688e7485"),
    tags: ["ai", "productivity", "llm", "writing", "research"],
    intro:
      "AI assistants have moved from novelty to daily tool for a very large number of people, largely without anyone explaining how they work well enough to use them safely. The result is two failure modes: treating the output as an oracle, or dismissing the tool entirely after one confident falsehood. Neither is necessary. What follows is a practical account of where these systems are genuinely strong, where they are structurally weak, and how to work with both.",
    sections: [
      {
        heading: "What the model is doing",
        body: [
          "A language model predicts likely continuations of text. It has no database lookup step and no internal sense of certainty about facts. Fluency and accuracy are separate properties, and the model optimises the first.",
          "This explains the single most important behaviour to anticipate: a plausible, well-structured, entirely incorrect answer, delivered with the same tone as a correct one. There is no stylistic tell.",
          "It also explains what these systems are excellent at. Transformation of text you provide, summarising, restructuring, drafting, translating, explaining a concept in different words, and generating options are all tasks where fluency is the point and where you supply the ground truth.",
        ],
        image: img("photo-1677442136019-21780ecad995"),
        imageAlt: "Abstract visualisation of a neural network",
        imageCaption:
          "Fluency and accuracy are separate properties. Only one is being optimised.",
      },
      {
        heading: "Prompts that reliably work better",
        sub: "Specificity, context, format",
        body: [
          "Give the role and the audience. Asking for an explanation of a tax rule for a first-time filer produces a different and more useful answer than asking for an explanation of a tax rule.",
          "Supply the source material rather than relying on recall. Pasting the document, the code, the policy or the data and asking for work on it moves the task from recall, where the model is weak, to transformation, where it is strong.",
          "State the output format and the constraints up front: length, structure, tone, what to exclude. Then iterate by criticising the draft rather than restarting. Feedback on a concrete draft steers far better than a longer initial prompt.",
        ],
        bullets: [
          "Name the audience and the purpose",
          "Paste the source instead of relying on memory",
          "Specify format, length and exclusions",
          "Iterate on the draft rather than re-prompting from scratch",
        ],
      },
      {
        heading: "Where it will fail, predictably",
        body: [
          "Precise figures, dates, citations, legal clauses, prices and statistics are the highest-risk outputs. These are exactly the details that look most authoritative and are most often fabricated or outdated.",
          "Arithmetic over more than a few steps, counting items in a long list, and reasoning about very recent events are similarly unreliable unless the tool has explicit calculation or search capability and visibly uses it.",
          "Anything where being wrong has consequences — medical, legal, financial, or safety — needs a human expert in the loop. Use the assistant to prepare questions and understand vocabulary, not to make the decision.",
        ],
      },
      {
        heading: "A verification habit that takes seconds",
        body: [
          "Ask for sources and then open them. A real citation resolves to a real page containing the claim. A fabricated one either does not resolve or resolves to something that does not say what was claimed.",
          "Cross-check any number that will be reused. If a figure is going into a document, a spreadsheet or a decision, it needs a primary source regardless of how confident the answer sounded.",
          "Re-ask the same question in a fresh session with different phrasing. Consistent answers across independent attempts are weak evidence of correctness; inconsistent ones are strong evidence of a problem.",
        ],
        image: img("photo-1554224155-6726b3ff858f"),
        imageAlt: "Person reviewing data on a laptop screen",
        imageCaption:
          "Every number that gets reused needs a primary source behind it.",
      },
      {
        heading: "Privacy and what you paste",
        sub: "Assume the text leaves your device",
        body: [
          "Unless you are running a local model, your prompt is transmitted and may be retained. Treat the input box like a message to a third party, because that is what it is.",
          "Do not paste identity documents, full account numbers, private keys, client contracts under confidentiality, or medical records. Redact identifiers and paste the structure you need help with instead; the model does not need real names to fix your paragraph.",
          "Check the retention and training settings of the tool you use. Most offer a way to exclude your conversations from training, and business tiers usually make it the default.",
        ],
      },
      {
        heading: "The right mental model",
        body: [
          "Treat it as a fast, tireless, widely-read assistant who is occasionally and confidently wrong, and who cannot tell you which times those are. You would happily hand that person a draft to improve. You would not hand them a decision.",
          "Used that way it is a genuine productivity gain. Used as an oracle it is a liability, and the difference is entirely in the verification habit, not in the model.",
        ],
      },
    ],
  },
  {
    slug: "smartphone-buying-guide-2026",
    title: "How to Choose a Phone in 2026 Without Overpaying",
    excerpt:
      "Which specifications still affect daily experience, which are marketing, and a decision framework built around software support rather than benchmark scores.",
    category: "Hardware",
    date: "2026-08-08",
    updated: "2026-08-25",
    readingTime: "12 min read",
    author: "Ravi Menon",
    image: img("photo-1511707171634-5f897ff02aa9"),
    tags: ["hardware", "mobile", "buying guide", "smartphones", "reviews"],
    intro:
      "Phone specifications stopped predicting phone experience some years ago. A mid-range device today outperforms a flagship from four years back at every task most people perform, which means the buying decision has shifted from raw capability to longevity, software policy and a small number of components that genuinely differ. This is a framework for spending the right amount, built around what still varies.",
    sections: [
      {
        heading: "Start with the support window",
        body: [
          "The single most consequential specification is how many years of operating system and security updates the manufacturer commits to in writing. A device that stops receiving security patches is a device you should stop using for banking, regardless of how well it still runs.",
          "Commitments now range from roughly two years at the bottom of the market to seven at the top. A phone costing forty percent more with double the support window is usually cheaper per year of safe use.",
          "Check the written policy, not the marketing claim, and check whether it covers the specific model rather than the flagship in the same family.",
        ],
        image: img("photo-1512499617640-c74ae3a79d37"),
        imageAlt: "Several modern smartphones arranged on a surface",
        imageCaption:
          "Cost per year of supported use is the number that matters, not sticker price.",
      },
      {
        heading: "Specifications that still change daily life",
        sub: "A short list",
        body: [
          "Display brightness in direct sunlight, because a dim panel makes a phone unusable outdoors regardless of resolution. Look at peak brightness figures, not resolution above a certain point, since pixel density differences stopped being visible years ago.",
          "Battery capacity combined with the efficiency of the chip, which together determine whether you finish a day without anxiety. Reviews that report screen-on time are more useful than capacity alone.",
          "Storage, because it cannot be upgraded on most modern phones and running near full degrades performance and complicates updates. The step from the base tier to the next one is the best value upgrade on almost any model.",
          "Main camera sensor size and stabilisation, which affect low-light photographs far more than megapixel counts do.",
        ],
        bullets: [
          "Peak outdoor brightness over resolution",
          "Real screen-on time over battery capacity",
          "One storage tier up, always",
          "Sensor size and stabilisation over megapixels",
        ],
      },
      {
        heading: "Specifications that are mostly marketing",
        body: [
          "Megapixel counts above the point where sensor size becomes the limit. Very high numbers are usually achieved by combining pixels anyway, producing an image at a fraction of the advertised figure.",
          "Benchmark scores, which measure short bursts under ideal thermal conditions. Sustained performance after ten minutes is what you feel, and it is rarely quoted.",
          "Charging speed beyond a certain point, which is genuinely convenient but has diminishing returns and a thermal cost. The difference between thirty minutes and eighteen minutes to eighty percent rarely changes a day.",
          "Refresh rates above the level your eye reliably distinguishes, particularly when the higher mode is disabled by the battery saver you will end up using.",
        ],
      },
      {
        heading: "Buying at the right moment",
        body: [
          "Prices on a given model follow a predictable curve: high at launch, a meaningful drop when the successor is announced, and the best value roughly six to nine months into the cycle.",
          "Last year's flagship at a discount is usually a better purchase than this year's mid-range at the same price, provided its support window still has several years left. Check that condition first, because it is the one that expires.",
          "Watch for regional variants with different chips or memory under an identical model name. The specification sheet for your market is the one that applies.",
        ],
        image: img("photo-1573148195900-7845dcb9b127"),
        imageAlt: "A person comparing devices in a retail setting",
        imageCaption:
          "Last year's flagship often wins, provided its update window still has years to run.",
      },
      {
        heading: "Repairability and the total cost",
        sub: "Ownership is longer than the warranty",
        body: [
          "Look up the cost of a battery replacement and a screen replacement before buying. Those two repairs cover the overwhelming majority of real-world damage, and the price gap between models is often larger than the price gap between the phones themselves.",
          "Check parts availability in your country and whether independent repair is possible or whether the device is locked to authorised service. A cheap phone with unobtainable parts is expensive the first time it falls.",
          "Factor in the case and screen protector as part of the purchase. They are not accessories; they are the difference between a five-year device and a two-year one.",
        ],
      },
      {
        heading: "The decision in three steps",
        body: [
          "Set a budget, then filter to devices with at least four years of remaining security support. Within that set, rank by real screen-on time and outdoor brightness. Then take the storage upgrade with whatever budget remains.",
          "This procedure ignores benchmarks entirely and produces a better daily experience than optimising for them, because it optimises for the properties that still differ between devices.",
        ],
      },
    ],
  },
  {
    slug: "online-scams-detection-guide",
    title: "How to Spot an Online Scam Before You Lose Money",
    excerpt:
      "The recurring scripts behind job offers, investment groups, delivery notices and support calls, plus a thirty-second verification routine that defeats almost all of them.",
    category: "Security",
    date: "2026-08-05",
    updated: "2026-08-26",
    readingTime: "13 min read",
    author: "Maya Iyer",
    image: img("photo-1563986768494-4dee2763ff3f"),
    tags: ["security", "scams", "fraud", "phishing", "safety"],
    intro:
      "Scams are not clever. They are repetitive, and they work through volume and emotional pressure rather than technical sophistication. Once you can recognise the handful of underlying scripts, the specific story stops mattering. This guide catalogues the patterns currently in wide circulation, explains the psychology each one exploits, and gives a verification routine short enough that you will actually use it.",
    sections: [
      {
        heading: "Every scam needs urgency",
        body: [
          "The common structure is a deadline that prevents you from checking. Your account will be suspended today, the offer closes in an hour, the delivery returns to the warehouse this evening, the case will be filed unless you speak now.",
          "Urgency is engineered because verification is fatal to the scam. Any legitimate organisation can wait ten minutes while you call them back on a number you looked up yourself. Every scam collapses at that step, without exception.",
          "This gives you a rule that requires no expertise: pressure to act immediately is itself the warning sign, independent of how plausible the story sounds.",
        ],
        image: img("photo-1516321318423-f06f85e504b3"),
        imageAlt: "A person looking at a suspicious message on a phone",
        imageCaption:
          "Urgency exists to prevent verification. That is its only function.",
      },
      {
        heading: "The scripts in current circulation",
        sub: "Different stories, same three moves",
        body: [
          "Task and commission jobs. You are paid small amounts for trivial tasks, then invited into a group where a larger deposit unlocks higher earnings. Early withdrawals succeed to build trust. The larger deposit never comes back.",
          "Investment groups with a mentor. A friendly contact, often after a wrong-number message that turns into weeks of conversation, introduces a trading platform showing rising balances. The platform is a display; there are no trades. Withdrawal requests trigger a tax or fee demand.",
          "Delivery and customs notices. A small fee is requested to release a parcel. The purpose is not the fee; it is capturing card details on a convincing payment page.",
          "Support and law enforcement calls. Someone claims your device is infected or your identity is implicated in a crime, and requests remote access or a transfer to a safe account. No such thing as a safe account exists.",
        ],
        bullets: [
          "Payment required before you receive anything",
          "A platform that shows profits but blocks withdrawal",
          "A request for remote access to your device",
          "A move from a public app to a private chat",
        ],
      },
      {
        heading: "Why intelligent people fall for these",
        body: [
          "The targeting is not random. Scripts are refined against thousands of attempts, and the ones you receive are the survivors of that selection. They are tuned to be persuasive.",
          "They also arrive at bad moments. A delivery notice during a week you ordered three parcels, a job offer during a job search, a bank alert while travelling. Context does most of the work.",
          "The final factor is sunk cost. Once someone has deposited, the pressure to recover it by depositing again is enormous, and the scam is designed around exactly that. This is why recovery scams targeting previous victims are so effective.",
        ],
      },
      {
        heading: "The thirty-second routine",
        body: [
          "Stop and breathe. The deadline is fabricated; treating it as real is the whole trap.",
          "Verify through a channel you chose. Close the message, open the official app or type the address yourself, or call the number printed on your card. Never use a link, number or address supplied by the person contacting you.",
          "Ask what money is moving and in which direction. If you are being asked to send money to receive money, it is a scam every single time, with no legitimate exception.",
          "Tell one other person out loud before acting. Saying the story to another human breaks the isolation the script depends on, and it is astonishingly effective.",
        ],
        image: img("photo-1552664730-d307ca884978"),
        imageAlt: "Two people discussing something on a laptop",
        imageCaption:
          "Saying the story out loud to someone else defeats the isolation the script relies on.",
      },
      {
        heading: "If it already happened",
        sub: "Speed decides recovery",
        body: [
          "Report to your bank immediately and in writing, and to the national cybercrime helpline. Money is far more recoverable while it sits in the first receiving account, which is usually a window measured in hours.",
          "Freeze cards, revoke any remote access application installed, change the passwords for email and banking from a different, clean device, and check for new mandates or beneficiaries added to your accounts.",
          "Then be alert for the second wave. Victim lists circulate, and a call offering to recover your lost funds for a fee is the same operation returning.",
        ],
      },
      {
        heading: "Protecting people who are targeted most",
        body: [
          "Older relatives and new smartphone users receive disproportionate volumes. The useful intervention is not a lecture about specific scams, which change monthly, but a standing agreement: any request for money or codes gets a call to you first, no matter who it appears to come from.",
          "Set that agreement up in advance and make it unembarrassing to use. A five-second call has stopped more losses than any awareness campaign.",
        ],
      },
    ],
  },
  {
    slug: "learn-to-code-roadmap",
    title: "Learning to Code in 2026: An Honest Roadmap",
    excerpt:
      "What actually produces employable skill, how long each stage genuinely takes, and how AI tools change what beginners should practise.",
    category: "Web Development",
    date: "2026-08-02",
    updated: "2026-08-25",
    readingTime: "13 min read",
    author: "Elena Ford",
    image: img("photo-1461749280684-dccba630e2f6"),
    tags: ["web development", "career", "learning", "javascript", "beginners"],
    intro:
      "The hard part of learning to code has never been the syntax. It is the long middle stretch between finishing tutorials and being able to build something nobody has written instructions for. Most roadmaps skip that stretch because it is uncomfortable to describe. This one is built around it, with realistic timelines, a defensible order for what to learn, and an account of what changes now that AI assistants can produce working code on request.",
    sections: [
      {
        heading: "Pick one path and stop comparing",
        body: [
          "The most common failure is not choosing a difficult language. It is switching languages every few weeks in search of the optimal one. Every mainstream language leads to employment; none of them is a mistake.",
          "For most beginners, web development is the pragmatic choice because feedback is immediate and visual, the tooling is free, and the job market is large. JavaScript with HTML and CSS, or Python for data and automation work, both work well.",
          "Commit for six months before reconsidering. The skills that transfer between languages — decomposition, debugging, reading documentation, modelling data — are the slow ones, and switching resets your progress on them.",
        ],
        image: img("photo-1498050108023-c5249f4df085"),
        imageAlt: "Code displayed on a laptop screen in a workspace",
        imageCaption:
          "The transferable skills are the slow ones. Switching languages resets them.",
      },
      {
        heading: "Realistic timelines",
        sub: "For consistent part-time study",
        body: [
          "Roughly one to two months to be comfortable with syntax, control flow, functions and basic data structures. This stage feels productive because tutorials work and errors are simple.",
          "Then three to six months in the difficult middle, building projects without instructions. Progress feels slower here even though this is where almost all real learning happens, because the errors are now design errors rather than typos.",
          "Then six to twelve months to reach a portfolio and skill level that is competitive for a first role, assuming steady effort and at least two substantial projects that a stranger can use.",
          "Anyone promising employment in six weeks is selling something. Anyone saying it takes a decade is describing mastery, not employability.",
        ],
        bullets: [
          "Months 1-2: syntax and fundamentals",
          "Months 3-8: unguided projects, the real learning",
          "Months 9-14: depth, portfolio, and interviewing",
          "Throughout: read other people's code weekly",
        ],
      },
      {
        heading: "Projects beat courses after the first month",
        body: [
          "Tutorials teach recognition; projects teach recall and judgement. The gap between watching someone build an application and building one yourself is the entire skill.",
          "Choose projects with a real user, even if that user is you. A tool that solves an annoyance you actually have will keep you working through the unglamorous parts — error handling, edge cases, deployment — which are exactly the parts employers assess.",
          "Finish and deploy. An abandoned ambitious project teaches far less than a small completed one, because everything hard about software lives in the last twenty percent.",
        ],
      },
      {
        heading: "What AI assistants change, and what they do not",
        body: [
          "They compress the syntax stage dramatically. Looking up how to write a loop or a fetch call is no longer a meaningful time cost, and that is a genuine gain.",
          "They do not compress the judgement stage. Deciding what to build, how to structure data, why a system is slow, and whether the generated code is correct are all still on you, and they are what the job consists of.",
          "The dangerous pattern is accepting code you cannot explain. It builds an illusion of progress that collapses in the first interview or the first production bug. A workable discipline: use the assistant freely, then close it and re-implement the same thing from memory. If you cannot, you have not learned it yet.",
        ],
        image: img("photo-1555949963-ff9fe0c870eb"),
        imageAlt: "Developer working with multiple code windows",
        imageCaption:
          "Use the assistant, then rewrite it from memory. That gap is your actual skill level.",
      },
      {
        heading: "The order that works",
        sub: "Depth before breadth",
        body: [
          "HTML and CSS properly, including layout with flexbox and grid, and responsive design. This is undervalued and immediately visible in everything you build.",
          "JavaScript fundamentals including asynchronous behaviour, which is where most beginners stall. Then one framework, learned deeply rather than three learned shallowly.",
          "Version control from day one, because employers assume it and it costs nothing to start. Then the basics of how the web works: requests, status codes, authentication, and what a server actually does.",
          "Databases and one backend environment last, once you have something worth persisting. Learning them before you need them produces knowledge that does not stick.",
        ],
      },
      {
        heading: "Getting the first role",
        body: [
          "Two deployed projects with clean code and a written explanation of the decisions behind them outperform ten tutorial clones. Employers read the explanation as evidence of judgement.",
          "Contribute to something open source, even documentation fixes. It demonstrates that you can work inside an unfamiliar codebase, which is the single most relevant simulation of the job.",
          "Apply before you feel ready. Every job description lists an idealised candidate, and the gap between the listing and the actual requirement is wider than anyone learning tends to believe.",
        ],
      },
    ],
  },
  {
    slug: "digital-decluttering-and-focus",
    title: "Digital Decluttering: Reclaiming Attention Without Deleting Everything",
    excerpt:
      "A systematic approach to notifications, apps, inboxes and screen habits, based on what changes behaviour rather than what feels virtuous.",
    category: "Developer Tools",
    date: "2026-07-29",
    updated: "2026-08-24",
    readingTime: "11 min read",
    author: "UPISTEPS Editorial",
    image: img("photo-1499750310107-5fef28a66643"),
    tags: ["productivity", "focus", "digital wellbeing", "tools", "habits"],
    intro:
      "Attention advice usually arrives as moral instruction: use your phone less, be more present. That framing fails because it treats a designed system as a personal weakness. The applications competing for your attention are built by large teams with detailed behavioural data. Willpower is not the counterweight. Changing the environment is, and environment changes are one-time actions that keep working after the motivation fades.",
    sections: [
      {
        heading: "Notifications are the whole problem",
        body: [
          "Nearly every unplanned phone pickup begins with an interruption you did not choose. Removing the interruption removes the pickup, and it does so without requiring any ongoing discipline.",
          "Default to off. Turn off every notification, then add back only the ones where a delay of several hours would cause a real problem. In practice that is direct messages from a small number of people, calendar events, and the occasional payment or delivery alert.",
          "Notice what did not make the list: social apps, news, shopping, games, and every product notifying you that other people are active. None of these are information; they are re-engagement prompts.",
        ],
        image: img("photo-1512941937669-90a1b58e7e9c"),
        imageAlt: "A phone face down beside a notebook",
        imageCaption:
          "Turn everything off, then earn each one back. Most never come back.",
      },
      {
        heading: "Friction is more effective than rules",
        sub: "Design the environment, not the intention",
        body: [
          "Remove the applications you overuse from your home screen entirely and reach them through search. The extra three seconds interrupts the automatic gesture, which is what most usage actually is.",
          "Log out of the ones that matter most. Re-entering credentials converts an unconscious open into a decision, and a surprising proportion of the time the decision is no.",
          "Move consumption to a device you have to sit down at. The same content on a laptop occupies a fraction of the time it does on a phone, because the phone is available in every idle moment and the laptop is not.",
        ],
        bullets: [
          "Empty home screen, apps reached via search",
          "Log out of the biggest time sinks",
          "Greyscale during focus hours",
          "Charger outside the bedroom",
        ],
      },
      {
        heading: "The inbox, properly",
        body: [
          "Email volume is mostly subscription, not correspondence. Spend twenty minutes unsubscribing rather than archiving, and the reduction is permanent instead of daily.",
          "Filter aggressively into folders that do not notify: receipts, newsletters, notifications from services. What remains in the inbox is then genuinely addressed to you, and it is a much smaller number than it appears today.",
          "Check on a schedule rather than continuously. Two or three defined times a day handles almost every real workload, and continuous checking substitutes the feeling of responsiveness for actual output.",
        ],
      },
      {
        heading: "Auditing where the time goes",
        body: [
          "Before changing anything, look at the screen time report for the last week without judgement. The gap between where people believe their time goes and where it actually goes is usually large and usually specific to one or two applications.",
          "Target those specifically rather than reducing everything. Broad restrictions fail because they impose a cost on the uses that were fine, which builds resentment and gets abandoned.",
          "Re-measure after two weeks. Behaviour changes that do not show up in the numbers are not working, and it is better to know that than to keep applying a rule out of principle.",
        ],
        image: img("photo-1434030216411-0b793f4b4173"),
        imageAlt: "A tidy desk with a notebook and a laptop",
        imageCaption:
          "Measure first. The application you think is the problem often is not.",
      },
      {
        heading: "Keeping the tools that earn their place",
        sub: "This is not minimalism for its own sake",
        body: [
          "The goal is not fewer applications; it is fewer applications initiating contact with you. A note tool, a reading queue, a maps application and a messaging app you control are all net positive and should stay.",
          "Consolidate where you can. Two note apps means every note is in the wrong one. One capture location, reviewed regularly, removes a recurring low-level cost you probably stopped noticing.",
          "Delete accounts, not just applications. A removed app with a live account still emails you, still holds your data, and still reinstalls easily on a weak evening.",
        ],
      },
      {
        heading: "A weekend of setup, a year of benefit",
        body: [
          "Run the audit, strip notifications to the essential list, clear the home screen, unsubscribe properly, and move the charger out of the bedroom. That is most of the available benefit and it takes an afternoon.",
          "Then leave it alone. The point of environment design is that it does not require ongoing attention, which is the resource you were trying to protect in the first place.",
        ],
      },
    ],
  },
];
