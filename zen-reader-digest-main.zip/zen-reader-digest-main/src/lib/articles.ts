import { pillarArticles } from "./articles-pillars";

const unsplash = (id: string) =>
  `https://images.unsplash.com/${id}?auto=format&fit=crop&w=1600&q=80`;

const aiImg = unsplash("photo-1620712943543-bcc4688e7485");
const codeImg = unsplash("photo-1461749280684-dccba630e2f6");
const cloudImg = unsplash("photo-1451187580459-43490279c0fa");
const securityImg = unsplash("photo-1510511459019-5dda7724fd87");
const deviceImg = unsplash("photo-1512499617640-c74ae3a79d37");
const toolsImg = unsplash("photo-1498050108023-c5249f4df085");

export type Section = {
  heading?: string;
  sub?: string;
  body: string[];
  image?: string;
  imageAlt?: string;
  imageCaption?: string;
  bullets?: string[];
};

export type Article = {
  slug: string;
  title: string;
  excerpt: string;
  category: string;
  date: string;
  updated?: string;
  readingTime: string;
  author: string;
  image: string;
  tags: string[];
  intro: string;
  sections: Section[];
};

export const articles: Article[] = [
  {
    slug: "upi-payments-complete-guide-2026",
    title: "UPI Payments in 2026: The Complete Guide to Safe, Fast Digital Money",
    excerpt:
      "How UPI actually works under the hood, the fraud patterns to watch for, the limits every bank enforces, and a practical checklist to keep your money safe.",
    category: "Fintech",
    date: "2026-08-24",
    updated: "2026-08-27",
    readingTime: "14 min read",
    author: "UPISTEPS Editorial",
    image: unsplash("photo-1556742049-0cfed4f6a45d"),
    tags: ["upi", "payments", "fintech", "security", "banking", "india"],
    intro:
      "Unified Payments Interface moved from a convenience to plumbing. It now settles more consumer transactions in a single month than cards did in a year a decade ago. That scale makes it worth understanding properly: not just how to scan a code, but what happens in the four seconds between a tap and a confirmation, where failures come from, and how fraud actually reaches people. This guide is written for everyday users and for developers who build on top of the rails.",
    sections: [
      {
        heading: "What UPI really is",
        body: [
          "UPI is not a wallet. There is no balance stored anywhere in the middle. It is a messaging and routing layer that lets one bank account instruct another to move money, in real time, using an address you can say out loud instead of an account number and IFSC code.",
          "That address, the UPI ID or VPA, is a pointer. When you pay someone@bank, the network resolves the pointer to an underlying account, checks that the payer authorised the debit with a device-bound PIN, and settles the transfer. The important consequence is that your UPI ID is safe to share. It reveals a routing handle, not credentials.",
          "The second consequence is less comfortable. Because settlement is instant and irreversible, the network cannot claw money back the way a card chargeback does. Every safety mechanism has to sit before the payment, not after it.",
        ],
        image: unsplash("photo-1563013544-824ae1b704d3"),
        imageAlt: "A person completing a mobile payment on a smartphone",
        imageCaption: "Instant settlement means every safety check has to happen before you approve.",
      },
      {
        heading: "The four seconds after you tap",
        sub: "A step-by-step walkthrough",
        body: [
          "First, your app resolves the payee address and shows you a verified name pulled from the receiving bank. This name-check is the single most useful fraud control in the whole system, and it is the step most people skim.",
          "Second, the app builds a payment instruction and asks for your UPI PIN. The PIN is not sent to a server as a password. It is used to sign the request on your device, tied to the SIM and hardware registration you completed when you set the account up. This is why UPI cannot be set up from a stolen phone number alone.",
          "Third, the switch routes the signed instruction to the payer bank, which checks balance and risk rules, then to the payee bank, which credits the account. Finally, both banks return a status and your app renders success, pending, or failure.",
        ],
        bullets: [
          "Resolve address and confirm the verified payee name",
          "Sign the instruction on-device with your UPI PIN",
          "Payer bank authorises and debits",
          "Payee bank credits and both sides confirm",
        ],
      },
      {
        heading: "Why payments fail, and what each failure means",
        body: [
          "A declined payment is rarely money lost. The most common causes are bank-side timeouts during peak load, daily limit exhaustion, an inactive account on the receiving side, and PIN attempts exceeded.",
          "A pending status is different from a failure. Pending means the instruction is in flight and the network has not yet received a final answer from one of the banks. The correct response is to wait for the automatic reversal window rather than paying again, because a duplicate payment is a real transfer and has to be recovered from the recipient by goodwill.",
          "If a debit happens without a credit, the reversal is automatic in the vast majority of cases and typically lands within a business day. If it does not, raise a complaint in the app that initiated the payment, not the receiving one, because the payer bank owns the dispute.",
        ],
      },
      {
        heading: "Limits you should know before you need them",
        body: [
          "Limits exist at three separate layers, which is why two people can see different behaviour on the same day. The network sets an outer ceiling per transaction and per day. Your bank sets its own, usually lower, ceiling. Your app may set a third, and new accounts are commonly restricted for the first twenty-four hours.",
          "Certain categories, such as verified merchant payments for insurance, education and capital markets, carry higher ceilings than person-to-person transfers. If a large payment fails while a smaller one succeeds, a category limit is the usual explanation rather than a fault.",
          "Plan ahead for high-value transfers. Split across days, or use a bank transfer rail designed for larger sums, instead of retrying and burning attempts against a limit that resets on a fixed schedule.",
        ],
        image: unsplash("photo-1554224155-6726b3ff858f"),
        imageAlt: "Financial charts and figures on a screen",
        imageCaption: "Three separate limit layers decide whether a large transfer goes through.",
      },
      {
        heading: "How fraud actually reaches people",
        sub: "Almost none of it is technical",
        body: [
          "The rails themselves are rarely broken. Losses come from persuading a person to authorise a payment or to hand over control of a device. Understanding the scripts is more protective than any app setting.",
          "The collect-request trick is the most common. A stranger sends a request to pay, framed as a refund or a prize, and the victim enters a PIN expecting to receive money. Remember the rule with no exceptions: you never enter a UPI PIN to receive funds. A PIN authorises money leaving your account, always.",
          "The second pattern is screen sharing. A caller claiming to be from support asks you to install a remote-access app to fix a failed transaction. Once installed, they read one-time codes and drive the payment themselves. No legitimate bank or payment company will ever ask for remote access.",
          "The third is the lookalike merchant code, where a sticker at a shop counter is quietly covered by a different one. Confirming the verified payee name before you approve defeats it in a second.",
        ],
        bullets: [
          "Never enter a PIN to receive money",
          "Reject every collect request from an unknown handle",
          "Refuse remote access and screen sharing, always",
          "Read the payee name, not just the amount",
        ],
      },
      {
        heading: "A practical safety checklist",
        body: [
          "Set a device lock and a separate app lock so a snatched, unlocked phone is not a payment terminal. Keep the account linked to UPI funded with working balance rather than your full savings, and move surplus to an account with no UPI mandate attached.",
          "Turn on transaction alerts through both SMS and app notifications so a silent debit is impossible. Review your registered mandates and autopay approvals once a quarter, since recurring authorisations are where forgotten money leaks.",
          "If a fraud happens, speed decides recovery. Report within the golden hour to the national cybercrime helpline and to your bank in writing. Funds are far more likely to be frozen while they sit in the first receiving account.",
        ],
      },
      {
        heading: "For developers building on the rails",
        body: [
          "Treat the payment response as advisory and the reconciliation file as truth. Any integration that marks an order paid purely on a client-side callback will eventually ship goods for money it never received.",
          "Make idempotency keys mandatory on order creation so a user tapping twice cannot generate two live collect requests. Store the transaction reference against your order from the moment you create it, not after success.",
          "Design the pending state as a first-class outcome in your interface. Most support tickets in payment products are not failures; they are pending transactions with no explanation on screen.",
        ],
      },
      {
        heading: "Where this goes next",
        body: [
          "Credit lines on UPI, offline payments in low-connectivity areas, and cross-border acceptance are the three directions with real momentum. Each one widens the surface where trust matters, which pushes the same lesson forward: the fastest network in the world still settles at the speed of the slowest human decision in the chain.",
          "The habits in this guide cost seconds. Confirming a name, refusing a collect request, and never entering a PIN to receive money will protect more money than any feature a bank can ship.",
        ],
      },
    ],
  },
  {
    slug: "digital-privacy-playbook-2026",
    title: "The Digital Privacy Playbook: Practical Steps That Actually Protect You",
    excerpt:
      "A no-nonsense, tool-by-tool walkthrough of the privacy settings, habits and account hygiene that meaningfully reduce your risk online in 2026.",
    category: "Security",
    date: "2026-08-20",
    updated: "2026-08-26",
    readingTime: "13 min read",
    author: "UPISTEPS Editorial",
    image: unsplash("photo-1614064641938-3bbee52942c7"),
    tags: ["privacy", "security", "passwords", "2fa", "data", "phishing"],
    intro:
      "Most privacy advice fails because it is either too vague to act on or so extreme that nobody keeps it up for a week. This playbook is built the other way round: a short list of changes ranked by how much risk each one removes per minute spent. Work down it in order and stop wherever the cost stops feeling worth it. Even the first two sections put you ahead of the overwhelming majority of accounts that get compromised.",
    sections: [
      {
        heading: "Start with the account that owns everything",
        body: [
          "Your primary email is the master key. Every reset link, every recovery code and every account confirmation lands there. An attacker who owns it owns your bank, your cloud storage and your social presence, regardless of how strong those individual passwords are.",
          "Give that account a unique password used nowhere else, the strongest second factor you can enable, and a recovery path that does not depend on an SMS to a number that can be ported away. Then check the list of connected apps and revoke everything you no longer recognise.",
          "If you do nothing else in this guide, do this. It is roughly ten minutes and it removes the single largest category of catastrophic loss.",
        ],
        image: unsplash("photo-1555949963-aa79dcee981c"),
        imageAlt: "Security code on a laptop screen in a dark room",
        imageCaption: "Your email account is the recovery path for everything else you own.",
      },
      {
        heading: "Passwords: the only system that survives contact with reality",
        sub: "A manager, not a memory",
        body: [
          "Reused passwords are the reason breaches cascade. One leaked shopping site becomes a bank login because the same string protected both. No human can remember a hundred unique strings, which is why the answer is a password manager rather than more discipline.",
          "Pick any reputable manager, set one long passphrase you can actually recall, and let it generate everything else. Import your browser-saved logins, then use the manager's own breach report to fix the reused and exposed ones first.",
          "Passkeys are steadily replacing this entirely. Where a site offers a passkey, take it: there is no shared secret to steal, and phishing pages cannot collect one because the credential is bound to the real domain.",
        ],
        bullets: [
          "One unique credential per site, generated not invented",
          "A single strong passphrase protecting the vault",
          "Passkeys wherever they are offered",
          "Fix reused and breached entries before anything else",
        ],
      },
      {
        heading: "Second factors, ranked",
        body: [
          "Not all two-factor is equal. A hardware key or a passkey is the strongest, because it verifies the site's identity as well as yours. An authenticator app generating codes is a solid middle ground. SMS is the weakest, because a SIM swap moves your number to someone else's hands without touching your phone.",
          "SMS is still far better than nothing. If it is the only option a service supports, enable it, and separately ask your mobile operator to place a port-out lock on the number.",
          "Save your backup codes somewhere offline. The most common self-inflicted lockout is enabling strong two-factor on a new phone and discarding the recovery codes on the assumption the device will never be lost.",
        ],
      },
      {
        heading: "Shrinking your data footprint",
        body: [
          "Every app you grant location, contacts and microphone access to is a copy of your life sitting on someone else's server, governed by a policy you did not read. Auditing permissions once removes years of accumulated access.",
          "Go through your phone's privacy dashboard and downgrade location to while-using for everything except navigation and emergency tools. Revoke contact access from anything that is not a messaging app; that permission is how your address book ends up in advertising graphs.",
          "On the browser side, a content blocker and a search engine that does not build a profile cover most of the tracking you meet day to day. Clearing cookies periodically breaks the long-lived identifiers that stitch your sessions together.",
        ],
        image: unsplash("photo-1526374965328-7f61d4dc18c5"),
        imageAlt: "Abstract visualisation of flowing data",
        imageCaption: "Permissions granted once keep collecting data for years unless you revoke them.",
      },
      {
        heading: "Recognising phishing in the moment",
        sub: "The pressure is the tell",
        body: [
          "Modern phishing is well written and visually perfect. Spelling mistakes are no longer the signal. What remains constant is manufactured urgency: an account closing, a payment failing, a refund expiring, a delivery held. Urgency exists to stop you from checking.",
          "The reliable defence is a habit rather than a judgement. Never act inside a message. Close it, open the app or type the address yourself, and see whether the same alert is waiting for you there. If it is real, it will be.",
          "Treat unexpected attachments and shortened links as hostile by default, and treat any call that asks you to install software, share a screen or read out a code as fraud regardless of who it claims to be.",
        ],
      },
      {
        heading: "Devices, networks and backups",
        body: [
          "Automatic updates are the highest-value security setting on any device, because most real attacks use flaws that were patched months earlier. Turn them on everywhere and let reboots happen.",
          "Full-disk encryption is on by default on modern phones and most laptops; confirm it rather than assume it. Combine it with a lock screen that actually engages quickly, because physical access is a far more common threat than remote intrusion.",
          "Public networks are less dangerous than they once were now that nearly all traffic is encrypted in transit, but a reputable VPN still helps on hotel and airport connections. Finally, keep a backup you could restore from tomorrow: ransomware and a dropped phone have identical consequences without one.",
        ],
        bullets: [
          "Automatic updates on, everywhere",
          "Encryption confirmed and a fast-engaging lock screen",
          "One offsite backup you have actually tested",
        ],
      },
      {
        heading: "What to do in the first hour of a breach",
        body: [
          "Change the password on the affected account and on your primary email, in that order. Sign out all other sessions, which most services offer as a single button, then review the account's recent activity and connected devices.",
          "Check whether the recovery email or phone number was quietly changed; that is the standard move to lock the real owner out. Restore it, then rotate the second factor entirely rather than trusting the existing one.",
          "Tell the people affected. If a messaging or social account was involved, a short public note prevents your contacts from being scammed by someone wearing your name.",
        ],
      },
      {
        heading: "The honest summary",
        body: [
          "Privacy is not a product you buy once, and total anonymity is not a realistic goal for a person who wants to use the internet. What is realistic is being a substantially harder target than the default, which is where nearly all opportunistic attacks stop.",
          "Unique credentials, strong second factors, permissions kept short, updates applied and a backup you trust. Five habits, an afternoon of setup, and a risk profile that looks nothing like the one you started with.",
        ],
      },
    ],
  },
  {
    slug: "small-language-models-are-winning",
    title: "Small Language Models Are Quietly Winning",
    excerpt:
      "Compact models now handle most day-to-day tasks at a fraction of the cost. Here is why teams are downsizing their AI stack.",
    category: "Artificial Intelligence",
    date: "2026-08-14",
    readingTime: "6 min read",
    author: "Ravi Menon",
    image: aiImg,
    tags: ["ai", "llm", "machine learning", "inference", "cost"],
    intro:
      "For two years the answer to every AI problem was a bigger model. That reflex is fading. Teams shipping real products are discovering that a well-tuned small model, running close to the user, beats a giant general-purpose one on latency, cost and predictability.",
    sections: [
      {
        heading: "The economics changed first",
        body: [
          "Inference, not training, dominates the lifetime cost of an AI feature. A model that answers in 200 milliseconds for a tenth of a cent changes what you can afford to build: autocomplete on every keystroke, classification on every row, summaries on every ticket.",
          "Once a task is narrow enough to describe in a page of instructions, a 3B-parameter model fine-tuned on a few thousand examples usually matches its much larger cousin.",
        ],
      },
      {
        heading: "Where small models excel",
        sub: "Structured, repetitive, well-bounded work",
        body: [
          "Extraction, routing, tagging, tone rewriting, and schema-constrained generation are the sweet spot. These tasks have a clear right answer and a narrow output space, which is exactly what fine-tuning rewards.",
          "The bonus is determinism. Smaller output spaces mean fewer surprises in production, and far easier evaluation.",
        ],
      },
      {
        heading: "Where they still fall short",
        body: [
          "Long multi-step reasoning, open-ended research and code that spans many files still favour frontier models. The pragmatic pattern is a router: a small model handles the ninety percent, and escalates the rest.",
        ],
      },
      {
        heading: "How to migrate without regressions",
        sub: "Build the eval before you switch",
        body: [
          "Collect three hundred real requests, label the expected outputs, and freeze them as a test set. Swap the model, run the set, and compare. Anything below your threshold routes upward.",
          "Teams that skip this step usually roll back within a week, not because the small model was bad but because nobody could prove it was good.",
        ],
      },
    ],
  },
  {
    slug: "the-case-for-boring-frontends",
    title: "The Case for Boring Frontends",
    excerpt:
      "Server-rendered HTML, a little JavaScript, and fewer dependencies. Why the fastest sites in 2026 look surprisingly old-fashioned.",
    category: "Web Development",
    date: "2026-08-09",
    readingTime: "5 min read",
    author: "Elena Ford",
    image: codeImg,
    tags: ["frontend", "performance", "javascript", "ssr", "web"],
    intro:
      "The best-performing sites we audited this year had one thing in common: they were unremarkable. No exotic state library, no animation framework, no client-side router doing work the browser already does well.",
    sections: [
      {
        heading: "Every dependency is a tax",
        body: [
          "A package you add today is a package someone parses on a four-year-old phone tomorrow. The cost is not just kilobytes; it is main-thread time, which is the scarcest resource on mobile.",
        ],
      },
      {
        heading: "Render on the server, hydrate what moves",
        sub: "Islands, not oceans",
        body: [
          "Ship HTML for content and reserve JavaScript for widgets that genuinely need it: a search box, a carousel, a form with live validation. Everything else can be static.",
          "This is not nostalgia. Modern frameworks make the split explicit, so you get the ergonomics of components with the delivery profile of a static site.",
        ],
      },
      {
        heading: "Measure what users feel",
        body: [
          "Largest Contentful Paint and Interaction to Next Paint correlate with revenue far better than bundle size alone. Track them from real sessions, not just lab runs.",
        ],
      },
    ],
  },
  {
    slug: "cloud-costs-after-the-hype",
    title: "Cloud Costs After the Hype",
    excerpt:
      "Repatriation, committed spend, and the rise of the boring single server. A practical look at where infrastructure money goes.",
    category: "Cloud & Infrastructure",
    date: "2026-07-31",
    readingTime: "7 min read",
    author: "Marcus Reid",
    image: cloudImg,
    tags: ["cloud", "devops", "infrastructure", "cost", "kubernetes"],
    intro:
      "Cloud spend stopped being a line item and became a strategy question. The companies with healthy margins are not the ones using the fewest services; they are the ones who know exactly which workloads deserve elasticity.",
    sections: [
      {
        heading: "Elasticity has a price",
        body: [
          "You pay a premium for capacity you can release at any moment. For a workload with a flat, predictable curve, that premium buys nothing. Batch jobs, internal tools and steady APIs are the usual candidates for cheaper, dedicated capacity.",
        ],
      },
      {
        heading: "Right-size before you re-platform",
        sub: "Most savings are unglamorous",
        body: [
          "Idle staging environments, over-provisioned databases, forgotten snapshots and cross-zone traffic routinely account for a third of a bill. Fix those before you plan a migration.",
        ],
      },
      {
        heading: "Complexity is the hidden invoice",
        body: [
          "A cluster nobody understands costs engineering hours every week. Count that time. A simpler architecture that a single on-call engineer can reason about is often the cheapest option overall.",
        ],
      },
    ],
  },
  {
    slug: "passkeys-finally-replace-passwords",
    title: "Passkeys Finally Replace Passwords",
    excerpt:
      "Adoption crossed the tipping point this year. What developers need to change, and the migration traps to avoid.",
    category: "Security",
    date: "2026-07-22",
    readingTime: "6 min read",
    author: "Priya Nair",
    image: securityImg,
    tags: ["security", "passkeys", "authentication", "webauthn", "privacy"],
    intro:
      "Passkeys moved from a checkbox in the settings page to the default sign-in method for a majority of new accounts on the platforms we surveyed. The technology is settled; the migration is where teams struggle.",
    sections: [
      {
        heading: "What actually improves",
        body: [
          "Phishing resistance is the headline. A passkey is bound to an origin, so a lookalike domain simply cannot collect anything useful. Credential stuffing disappears along with the shared secret.",
        ],
      },
      {
        heading: "Design the fallback carefully",
        sub: "Recovery is the new weak link",
        body: [
          "Attackers move to whatever remains: email recovery links, support agents, SMS codes. Harden those paths at the same time you launch passkeys, or you have simply relocated the risk.",
        ],
      },
      {
        heading: "A staged rollout that works",
        body: [
          "Offer passkey enrolment after a successful password login, keep both methods active for a release cycle, then prompt for password removal once a second device is registered.",
        ],
      },
    ],
  },
  {
    slug: "on-device-ai-and-the-battery-problem",
    title: "On-Device AI and the Battery Problem",
    excerpt:
      "Neural accelerators are everywhere, but thermal budgets still decide what ships. A look at the real constraints.",
    category: "Hardware",
    date: "2026-07-11",
    readingTime: "5 min read",
    author: "Ravi Menon",
    image: deviceImg,
    tags: ["hardware", "mobile", "ai", "npu", "battery"],
    intro:
      "Every flagship phone now advertises an on-device model. Far fewer of them run it continuously, because sustained inference is a thermal problem long before it is a compute problem.",
    sections: [
      {
        heading: "Peak numbers mislead",
        body: [
          "Vendor benchmarks quote burst throughput. Sustained throughput after ten minutes is frequently half that, once the device throttles. Design your feature around the sustained figure.",
        ],
      },
      {
        heading: "Batch, cache, and defer",
        sub: "Do the work while charging",
        body: [
          "Indexing photos, generating embeddings and summarising documents can all wait for a charger and a cool chassis. Users never notice the delay; they notice a hot phone immediately.",
        ],
      },
    ],
  },
  {
    slug: "developer-tools-that-earn-their-keep",
    title: "Developer Tools That Earn Their Keep",
    excerpt:
      "A short, opinionated list of tooling that measurably shortened our feedback loop this year, and what we removed.",
    category: "Developer Tools",
    date: "2026-06-28",
    readingTime: "4 min read",
    author: "Elena Ford",
    image: toolsImg,
    tags: ["tools", "productivity", "testing", "ci", "developer experience"],
    intro:
      "Tooling should shorten the distance between writing a line of code and knowing whether it works. Judged by that single rule, most of our stack was replaceable.",
    sections: [
      {
        heading: "Keep: fast test runners and typed boundaries",
        body: [
          "A suite that finishes in under thirty seconds gets run. One that takes ten minutes gets skipped, and a skipped test is worse than no test because it implies coverage that does not exist.",
        ],
      },
      {
        heading: "Cut: dashboards nobody opens",
        sub: "Alerts over charts",
        body: [
          "If a metric matters, page someone when it moves. If it does not matter enough to page, it probably does not need a panel either.",
        ],
      },
    ],
  },
  ...pillarArticles,
];

export function getArticle(slug: string) {
  return articles.find((a) => a.slug === slug);
}

export const categories: string[] = Array.from(
  new Set(articles.map((a) => a.category)),
);

export const allTags: string[] = Array.from(
  new Set(articles.flatMap((a) => a.tags)),
).sort();

export function filterArticles(opts: {
  q?: string | undefined;
  category?: string | undefined;
  tag?: string | undefined;
}) {
  let list = searchArticles(opts.q ?? "");
  if (opts.category) list = list.filter((a) => a.category === opts.category);
  if (opts.tag) list = list.filter((a) => a.tags.includes(opts.tag!));
  return list;
}

export function searchArticles(query: string) {
  const q = query.trim().toLowerCase();
  if (!q) return articles;
  const terms = q.split(/\s+/);
  return articles.filter((a) => {
    const haystack = [a.title, a.excerpt, a.category, a.author, ...a.tags]
      .join(" ")
      .toLowerCase();
    return terms.every((t) => haystack.includes(t));
  });
}

export function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}
