# The Tech Hub

"Create a professional, clean, and minimalist tech blog website.

​Design: Use a modern, mobile-responsive layout with a clean typography (easy to read). Ensure it is very fast and lightweight.

 ​Structure:

​Home Page: Must feature a 'Hero section' with a brief welcome, followed by a grid of 'Latest Tech Articles' (cards with an image, title, and short excerpt).

​Navigation: Simple top menu with links for 'Home', 'Blog', 'About', and 'Contact'. Include a visible 'Search' bar in the header.

​Article Page: A dedicated, reader-friendly page layout for blog posts with clear headings (H1, H2, H3) and enough spacing for readability.

​Footer: Must include links to 'About Us', 'Contact Us', 'Privacy Policy', and 'Terms & Conditions' pages.

​Functionality: Include a search feature to find articles by keywords.

​AdSense Ready: Ensure the layout has clean, empty space areas (like after the hero section, within the blog post content, and in the sidebar) where AdSense banners can be placed later.

​Style: Use a professional color palette (white background, dark grey text, and a primary accent color like deep blue or professional green)."

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://zen-reader-digest.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/2f081b0e-0473-4d74-8f0a-b8d79b04304f).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
